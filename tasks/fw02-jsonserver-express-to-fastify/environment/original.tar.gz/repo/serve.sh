#!/usr/bin/env bash
#
# Production entry point.
#
# Starts the packaged HTTP service the way a deployment would: through the
# executable this package declares in its own "bin" field, against a working
# copy of the seed database. Configuration comes from the environment so a
# supervisor can place the service anywhere:
#
#   JSON_SERVER_HOST     interface to bind             (default 127.0.0.1)
#   JSON_SERVER_PORT     port to bind                  (default 3000)
#   JSON_SERVER_SEED     read-only seed database       (default ./db.seed.json)
#   JSON_SERVER_DB       working database              (default $TMPDIR/db.json)
#   JSON_SERVER_ROUTES   rewrite rules, "" to disable  (default ./routes.json)
#
# Any extra arguments are appended to the command line, so operational variants
# ("--read-only", "--delay 200", ...) do not need their own launcher.
#
# The seed is copied to the working database on every boot: the service mutates
# its database in place, and a deployment must come up in a known state rather
# than inherit the previous run's writes.

set -euo pipefail

here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$here"

host="${JSON_SERVER_HOST:-127.0.0.1}"
port="${JSON_SERVER_PORT:-3000}"
seed="${JSON_SERVER_SEED:-$here/db.seed.json}"
db="${JSON_SERVER_DB:-${TMPDIR:-/tmp}/json-server-db.json}"
routes="${JSON_SERVER_ROUTES-$here/routes.json}"

if [ ! -f "$seed" ]; then
    echo "serve.sh: seed database not found: $seed" >&2
    exit 1
fi

mkdir -p "$(dirname "$db")"
cp -f "$seed" "$db"
chmod u+w "$db"

# Resolve the launcher from the package manifest rather than hard-coding a
# path: "bin" is part of the published release, and this is what a global
# install would run.
bin="$(node -e 'const b=require("./package.json").bin;
process.stdout.write(typeof b === "string" ? b : Object.values(b)[0]);')"

if [ ! -f "$bin" ]; then
    echo "serve.sh: declared bin does not exist: $bin" >&2
    echo "serve.sh: run the package build first (npm run build)" >&2
    exit 1
fi

args=("$db" --host "$host" --port "$port")
if [ -n "$routes" ]; then
    args+=(--routes "$routes")
fi

exec node "$bin" "${args[@]}" "$@"
