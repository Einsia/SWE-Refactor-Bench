// Command yaml-probe answers NDJSON requests about this library's behaviour on
// stdin and stdout.
//
// One request object per line in, one response object per line out, in order.  A
// blank input line is skipped and produces nothing.  End of input ends the
// session with status 0.  The protocol is package probe's; this program is the
// transport around it.
//
// It is deliberately this small.  Everything observable lives in package probe,
// so the same adapter is reachable from a test binary or from another program
// without going through a pipe.
package main

import (
	"fmt"
	"os"

	"gopkg.in/yaml.v3/probe"
)

func main() {
	if len(os.Args) > 1 && os.Args[1] != "serve" {
		fmt.Fprintf(os.Stderr, "usage: %s [serve]\n", os.Args[0])
		os.Exit(2)
	}
	if err := probe.Serve(os.Stdin, os.Stdout); err != nil {
		// A write error means the reader is gone, and a read error means the
		// request stream broke.  Neither is something to answer over a protocol
		// whose channel just failed, so it is reported on stderr and the status
		// carries it.
		fmt.Fprintf(os.Stderr, "yaml-probe: %v\n", err)
		os.Exit(1)
	}
}
