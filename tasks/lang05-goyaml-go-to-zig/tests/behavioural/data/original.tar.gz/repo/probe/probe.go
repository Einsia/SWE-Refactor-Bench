// Package probe is the library's differential test harness: an NDJSON
// request/response adapter over the exported yaml.Node API.
//
// It exists so that this library's observable behaviour -- what the scanner, the
// parser, the resolver and the emitter decide, for any input -- can be captured
// as bytes and compared against another implementation of the same library.  One
// request in, one response line out, no state carried between requests.
//
// Only the exported API is used, and that is a deliberate limit.  The parser's
// event stream is package private, and driving it directly would amount to
// dictating an implementation's internal structure.  yaml.Node is public,
// ordered, and carries every decision the scanner, parser and resolver make, so
// it can carry the whole differential without constraining how the library is
// built inside.
//
// What is NOT covered, and why: decoding into Go types (Unmarshal into a struct
// or into interface{}) and marshalling Go values back out.  Those paths run
// through reflect and through Go's own type lattice -- sorter.go orders map keys
// by reflect.Kind ordinal, resolve.go materialises time.Time -- so covering them
// would tie the harness to Go's runtime rather than to YAML.
//
// Requests are read with encoding/json.  That is safe in a way the response side
// is not: request bytes are produced by whoever is driving the harness and are
// never compared, so the two sides may each use whatever JSON reader they have.
// Responses are written by hand -- see jenc.go for the rule and the reason.
package probe

import (
	"bufio"
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"strings"

	"gopkg.in/yaml.v3"
)

// Version is the library version this harness reports through `hello`.  go-yaml
// exports no version constant, so it is stated here; a caller that needs to know
// which library answered it asks over the protocol rather than reading a build
// stamp.
const Version = "v3.0.1"

// Protocol is the wire version.  A response shape can only change by changing
// this.
const Protocol = 1

// Request is one operation.  HasIndent distinguishes a request that omits the
// indent from one that sends 0: SetIndent(0) is a real value with an observable
// effect, so treating a missing field as 0 would make the emit_indent contract
// untestable.
type Request struct {
	ID        int
	Op        string
	Source    string
	Indent    int
	HasIndent bool
}

// rawRequest mirrors the wire shape.  Indent is a pointer for the reason above.
type rawRequest struct {
	ID     int     `json:"id"`
	Op     string  `json:"op"`
	Source string  `json:"source"`
	Indent *int    `json:"indent"`
	Note   *string `json:"note"`
}

func toRequest(r rawRequest) Request {
	req := Request{ID: r.ID, Op: r.Op, Source: r.Source}
	if r.Indent != nil {
		req.Indent = *r.Indent
		req.HasIndent = true
	}
	return req
}

// A response is built as text, not as a value, because the encoding is the
// contract.  ok=false carries kind+message; ok=true carries a shape that is
// per-op.
type response struct {
	id     int
	ok     bool
	kind   string
	msg    string
	result string // pre-encoded JSON, valid only when ok
}

func errResp(id int, kind, msg string) response {
	return response{id: id, ok: false, kind: kind, msg: msg}
}

// recovered turns a panic that escaped the library into an ordinary failed
// response.  go-yaml signals its own errors by panicking with a private type and
// recovering at the API boundary, so anything that reaches here is either a
// library defect or a resource limit.  Either way one request should fail rather
// than the whole session, and the kind has to be distinguishable from a YAML
// error so a real crash is not mistaken for expected behaviour.
func recovered(id int, r interface{}) response {
	return errResp(id, "Panic", fmt.Sprint(r))
}

func parseFirst(src string) (*yaml.Node, error) {
	var n yaml.Node
	if err := yaml.Unmarshal([]byte(src), &n); err != nil {
		return nil, err
	}
	return &n, nil
}

// parseStream reads every document.  A failure part way through is reported
// alongside the documents that were read before it: a stream that yields two
// documents and then fails is evidence about all three outcomes, and folding it
// into a bare error would throw two thirds of that away.
func parseStream(src string) ([]*yaml.Node, error) {
	dec := yaml.NewDecoder(strings.NewReader(src))
	var docs []*yaml.Node
	for {
		var n yaml.Node
		err := dec.Decode(&n)
		if err == io.EOF {
			return docs, nil
		}
		if err != nil {
			return docs, err
		}
		docs = append(docs, &n)
	}
}

func emitOne(n *yaml.Node, indent int, setIndent bool) (string, error) {
	var buf bytes.Buffer
	enc := yaml.NewEncoder(&buf)
	if setIndent {
		enc.SetIndent(indent)
	}
	if err := enc.Encode(n); err != nil {
		return "", err
	}
	if err := enc.Close(); err != nil {
		return "", err
	}
	return buf.String(), nil
}

func emitAll(docs []*yaml.Node, indent int, setIndent bool) (string, error) {
	var buf bytes.Buffer
	enc := yaml.NewEncoder(&buf)
	if setIndent {
		enc.SetIndent(indent)
	}
	for _, d := range docs {
		if err := enc.Encode(d); err != nil {
			return buf.String(), err
		}
	}
	if err := enc.Close(); err != nil {
		return buf.String(), err
	}
	return buf.String(), nil
}

func handle(req Request) (resp response) {
	defer func() {
		if r := recover(); r != nil {
			resp = recovered(req.ID, r)
		}
	}()

	var b strings.Builder
	switch req.Op {
	case "hello":
		b.WriteString(`{`)
		first := true
		intField(&b, &first, "protocol", Protocol)
		strField(&b, &first, "library", "gopkg.in/yaml.v3")
		strField(&b, &first, "upstream", Version)
		b.WriteString(`}`)

	case "node":
		n, err := parseFirst(req.Source)
		if err != nil {
			return errResp(req.ID, "YamlError", err.Error())
		}
		b.WriteString(`{`)
		first := true
		field(&b, &first, "node")
		encNode(&b, n)
		b.WriteString(`}`)

	case "stream":
		docs, err := parseStream(req.Source)
		b.WriteString(`{`)
		first := true
		field(&b, &first, "docs")
		b.WriteByte('[')
		for i, d := range docs {
			if i > 0 {
				b.WriteByte(',')
			}
			encNode(&b, d)
		}
		b.WriteByte(']')
		field(&b, &first, "error")
		if err != nil {
			encStr(&b, err.Error())
		} else {
			b.WriteString("null")
		}
		b.WriteString(`}`)

	case "emit", "emit_indent":
		setIndent := req.Op == "emit_indent"
		if setIndent && !req.HasIndent {
			return errResp(req.ID, "ProtocolError", "emit_indent requires an indent")
		}
		if setIndent && req.Indent < 0 {
			return errResp(req.ID, "ProtocolError", "indent must not be negative")
		}
		n, err := parseFirst(req.Source)
		if err != nil {
			return errResp(req.ID, "YamlError", err.Error())
		}
		out, err := emitOne(n, req.Indent, setIndent)
		if err != nil {
			return errResp(req.ID, "YamlError", err.Error())
		}
		b.WriteString(`{`)
		first := true
		strField(&b, &first, "out", out)
		b.WriteString(`}`)

	case "emit_stream":
		docs, perr := parseStream(req.Source)
		out, eerr := emitAll(docs, 0, false)
		b.WriteString(`{`)
		first := true
		strField(&b, &first, "out", out)
		field(&b, &first, "error")
		switch {
		case perr != nil:
			encStr(&b, perr.Error())
		case eerr != nil:
			encStr(&b, eerr.Error())
		default:
			b.WriteString("null")
		}
		b.WriteString(`}`)

	// roundtrip feeds the emitter's own output back to the parser.  That is a
	// different input distribution from hand-written YAML -- canonically
	// indented, canonically quoted -- and it is where an emitter that produces
	// text its own parser reads differently shows up.
	case "roundtrip":
		n, err := parseFirst(req.Source)
		if err != nil {
			return errResp(req.ID, "YamlError", err.Error())
		}
		firstOut, err := emitOne(n, 0, false)
		if err != nil {
			return errResp(req.ID, "YamlError", err.Error())
		}
		n2, err := parseFirst(firstOut)
		if err != nil {
			b.WriteString(`{`)
			f := true
			strField(&b, &f, "first", firstOut)
			field(&b, &f, "reparse_error")
			encStr(&b, err.Error())
			b.WriteString(`}`)
			break
		}
		secondOut, err := emitOne(n2, 0, false)
		if err != nil {
			b.WriteString(`{`)
			f := true
			strField(&b, &f, "first", firstOut)
			field(&b, &f, "reemit_error")
			encStr(&b, err.Error())
			b.WriteString(`}`)
			break
		}
		b.WriteString(`{`)
		f := true
		strField(&b, &f, "first", firstOut)
		strField(&b, &f, "second", secondOut)
		field(&b, &f, "stable")
		encBool(&b, firstOut == secondOut)
		b.WriteString(`}`)

	default:
		return errResp(req.ID, "ProtocolError", "unknown op: "+req.Op)
	}

	return response{id: req.ID, ok: true, result: b.String()}
}

// encode writes the response envelope: id, ok, then either result or error.
func encode(r response) string {
	var b strings.Builder
	b.WriteByte('{')
	first := true
	intField(&b, &first, "id", r.id)
	field(&b, &first, "ok")
	encBool(&b, r.ok)
	if r.ok {
		field(&b, &first, "result")
		b.WriteString(r.result)
	} else {
		field(&b, &first, "error")
		b.WriteByte('{')
		ef := true
		strField(&b, &ef, "kind", r.kind)
		strField(&b, &ef, "message", r.msg)
		b.WriteByte('}')
	}
	b.WriteByte('}')
	return b.String()
}

// AnswerRequest answers a request that has already been built.  The returned
// string is one response line, without the newline.
func AnswerRequest(req Request) string {
	return encode(handle(req))
}

// Answer answers one wire line.  A line that is not readable JSON is answered
// with a ProtocolError against id 0 rather than dropped: a session that stops
// replying leaves the two streams out of step, which is a worse failure than a
// wrong answer.
func Answer(line []byte) string {
	var raw rawRequest
	if err := json.Unmarshal(line, &raw); err != nil {
		return encode(errResp(0, "ProtocolError", "bad request line"))
	}
	return AnswerRequest(toRequest(raw))
}

// MaxRequestBytes is the largest request line this harness accepts.  One
// document is a single line holding a whole YAML file, and bufio.Scanner's
// default 64 KiB limit would silently truncate a large one into a parse error
// attributed to the input rather than to the transport.
const MaxRequestBytes = 64 << 20

// NewScanner reads request lines with a buffer large enough for the above.
func NewScanner(r io.Reader) *bufio.Scanner {
	sc := bufio.NewScanner(r)
	sc.Buffer(make([]byte, 0, 1<<20), MaxRequestBytes)
	return sc
}

// Serve answers requests from r on w until r reaches EOF.
//
// Output is flushed per line because a caller writes a request and then blocks
// on a response; a buffered reply would deadlock rather than fail.  Blank lines
// are skipped and produce no response, so a caller that writes one does not fall
// out of step.
func Serve(r io.Reader, w io.Writer) error {
	sc := NewScanner(r)
	bw := bufio.NewWriter(w)
	for sc.Scan() {
		line := sc.Bytes()
		if len(line) == 0 {
			continue
		}
		if _, err := bw.WriteString(Answer(line)); err != nil {
			return err
		}
		if err := bw.WriteByte('\n'); err != nil {
			return err
		}
		if err := bw.Flush(); err != nil {
			return err
		}
	}
	return sc.Err()
}
