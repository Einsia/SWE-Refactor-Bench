package probe

// The node shape.
//
// yaml.Node is the whole covered surface, so what gets written here is the
// contract.  Every decision the scanner, the parser and the resolver make is
// visible in one of these fields: Style carries the quoting and flow decisions as
// a bitmask, Tag carries resolution, the three comment fields carry comment
// attachment, and Line/Column carry position.
//
// Two omissions are deliberate.  Alias is encoded as a bare `true` rather than as
// the node it points at: `&a [*a]` builds a node whose alias target is its own
// container, so a recursive encoder would not terminate, and the alias name is
// already in Value.  Content of an alias node is likewise not walked.

import (
	"fmt"
	"strings"

	"gopkg.in/yaml.v3"
)

func kindName(k yaml.Kind) string {
	switch k {
	case 0:
		return "none"
	case yaml.DocumentNode:
		return "doc"
	case yaml.SequenceNode:
		return "seq"
	case yaml.MappingNode:
		return "map"
	case yaml.ScalarNode:
		return "scalar"
	case yaml.AliasNode:
		return "alias"
	}
	// Unreachable for a node this library built.  Encoded rather than panicked so
	// a future kind shows up as a mismatch in one response instead of taking the
	// whole session down.
	return fmt.Sprintf("kind%d", int(k))
}

// encNode writes one node.  Key order is fixed and is part of the protocol:
// kind, style, tag, value, anchor, alias, head, line, foot, l, c, content.
// The string members and content are omitted when empty; kind, style, l and c
// are always present.
func encNode(b *strings.Builder, n *yaml.Node) {
	if n == nil {
		b.WriteString("null")
		return
	}
	b.WriteByte('{')
	first := true
	strField(b, &first, "kind", kindName(n.Kind))
	intField(b, &first, "style", int(n.Style))
	optStr(b, &first, "tag", n.Tag)
	optStr(b, &first, "value", n.Value)
	optStr(b, &first, "anchor", n.Anchor)
	if n.Alias != nil {
		field(b, &first, "alias")
		encBool(b, true)
	}
	optStr(b, &first, "head", n.HeadComment)
	optStr(b, &first, "line", n.LineComment)
	optStr(b, &first, "foot", n.FootComment)
	intField(b, &first, "l", n.Line)
	intField(b, &first, "c", n.Column)
	if len(n.Content) > 0 {
		field(b, &first, "content")
		b.WriteByte('[')
		for i, c := range n.Content {
			if i > 0 {
				b.WriteByte(',')
			}
			encNode(b, c)
		}
		b.WriteByte(']')
	}
	b.WriteByte('}')
}
