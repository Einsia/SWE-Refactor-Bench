package probe_test

import (
	"strings"
	"testing"

	"gopkg.in/yaml.v3/probe"
)

// The protocol's fixed points.  These are the rules another implementation of
// this library has to reproduce byte for byte, so they are asserted as bytes
// rather than as decoded values -- a test that unmarshalled the response would
// pass on output with the keys in a different order.
func TestAnswerShapes(t *testing.T) {
	cases := []struct {
		name string
		line string
		want string
	}{{
		name: "hello names the library and the version",
		line: `{"id":1,"op":"hello"}`,
		want: `{"id":1,"ok":true,"result":{"protocol":1,` +
			`"library":"gopkg.in/yaml.v3","upstream":"v3.0.1"}}`,
	}, {
		name: "a scalar carries kind, style, tag, value and position",
		line: `{"id":2,"op":"node","source":"x\n"}`,
		want: `{"id":2,"ok":true,"result":{"node":{"kind":"doc","style":0,` +
			`"l":1,"c":1,"content":[{"kind":"scalar","style":0,"tag":"!!str",` +
			`"value":"x","l":1,"c":1}]}}}`,
	}, {
		name: "an unknown op is a protocol error, not a crash",
		line: `{"id":3,"op":"nope"}`,
		want: `{"id":3,"ok":false,"error":{"kind":"ProtocolError",` +
			`"message":"unknown op: nope"}}`,
	}, {
		name: "an unreadable line is answered against id 0",
		line: `not json`,
		want: `{"id":0,"ok":false,"error":{"kind":"ProtocolError",` +
			`"message":"bad request line"}}`,
	}, {
		name: "emit_indent without an indent is refused",
		line: `{"id":4,"op":"emit_indent","source":"a: 1\n"}`,
		want: `{"id":4,"ok":false,"error":{"kind":"ProtocolError",` +
			`"message":"emit_indent requires an indent"}}`,
	}, {
		name: "a parse failure is a YamlError carrying the library's own text",
		line: `{"id":5,"op":"node","source":"a: [\n"}`,
		want: `{"id":5,"ok":false,"error":{"kind":"YamlError","message":` +
			`"yaml: line 1: did not find expected node content"}}`,
	}, {
		name: "a stream reports the documents it read and a null error",
		line: `{"id":6,"op":"emit_stream","source":"1\n---\n2\n"}`,
		want: `{"id":6,"ok":true,"result":{"out":"1\n---\n2\n","error":null}}`,
	}}

	for _, c := range cases {
		got := probe.Answer([]byte(c.line))
		if got != c.want {
			t.Errorf("%s:\n got %s\nwant %s", c.name, got, c.want)
		}
	}
}

// Every byte outside printable ASCII is escaped, so a response is pure ASCII
// whatever the input was.  This is what lets two implementations compare
// responses without first agreeing on how to write UTF-8.
func TestResponsesArePureASCII(t *testing.T) {
	for _, src := range []string{
		"k: \u00e9\n", "k: \u4e16\u754c\n", "k: \"\U0001f600\"\n",
		"k: \"a\\tb\"\n", "k: \"\\u2028\"\n", "k: <&>\n",
	} {
		got := probe.Answer([]byte(`{"id":1,"op":"node","source":` +
			quote(src) + `}`))
		for i := 0; i < len(got); i++ {
			if got[i] < 0x20 || got[i] > 0x7e {
				t.Fatalf("source %q: response byte %d is %#x, not printable "+
					"ASCII: %s", src, i, got[i], got)
			}
		}
	}
}

// Serve is the transport: one line in, one line out, in order, blank lines
// skipped.  A response per non-blank request and no response for a blank one is
// what keeps a caller's two streams in step.
func TestServeSkipsBlankLinesAndStaysInOrder(t *testing.T) {
	in := strings.Join([]string{
		`{"id":7,"op":"hello"}`,
		``,
		`{"id":8,"op":"hello"}`,
		``,
	}, "\n")
	var out strings.Builder
	if err := probe.Serve(strings.NewReader(in), &out); err != nil {
		t.Fatalf("Serve: %v", err)
	}
	lines := strings.Split(strings.TrimSuffix(out.String(), "\n"), "\n")
	if len(lines) != 2 {
		t.Fatalf("two requests produced %d response line(s): %q",
			len(lines), out.String())
	}
	for i, want := range []string{`"id":7`, `"id":8`} {
		if !strings.Contains(lines[i], want) {
			t.Errorf("response %d does not carry %s: %s", i, want, lines[i])
		}
	}
}

// quote writes a JSON string literal for the test inputs above.  strconv.Quote
// is not it: it produces Go escapes, which are not JSON's.
func quote(s string) string {
	var b strings.Builder
	b.WriteByte('"')
	for _, r := range s {
		switch r {
		case '"':
			b.WriteString(`\"`)
		case '\\':
			b.WriteString(`\\`)
		case '\n':
			b.WriteString(`\n`)
		case '\t':
			b.WriteString(`\t`)
		default:
			b.WriteRune(r)
		}
	}
	b.WriteByte('"')
	return b.String()
}
