package probe

// The response encoder.
//
// This is written out by hand rather than delegating to encoding/json, and the
// reason is the whole point of a differential test: the bytes on the wire are
// the thing being compared, so the rule that produces them has to be stateable
// in a paragraph and implementable identically in another language.  Go's
// encoder has three behaviours that would each become an undocumented part of
// the protocol -- HTML escaping of < > &, unconditional escaping of U+2028 and
// U+2029, and replacement of invalid UTF-8 with U+FFFD.  A port would have to
// discover them by failing cases.
//
// The rule, in full:
//   * no whitespace anywhere outside string literals
//   * object keys in the order the shape declares, never sorted
//   * bytes 0x20-0x7E appear literally, except " and \ which take a backslash
//   * 0x08 0x09 0x0A 0x0C 0x0D are \b \t \n \f \r
//   * every other code point is \uXXXX with lowercase hex, in surrogate pairs
//     above U+FFFF
// The last clause makes every response pure ASCII, which removes the question
// of how each side writes UTF-8 and makes a frozen expectation file diffable.

import (
	"strconv"
	"strings"
	"unicode/utf8"
)

const hexDigits = "0123456789abcdef"

// encStr appends the JSON form of s, escaping everything outside printable
// ASCII.  Input is assumed valid UTF-8; the parser guarantees it, because
// readerc.go rejects every malformed sequence, every lone surrogate and every
// code point above U+10FFFF before a value can reach a node.  A RuneError with
// size 1 would therefore be a defect in this driver rather than bad input, and
// it is encoded literally as U+FFFD so it shows up in a diff instead of being
// silently smoothed over.
func encStr(b *strings.Builder, s string) {
	b.WriteByte('"')
	for i := 0; i < len(s); {
		c := s[i]
		if c < utf8.RuneSelf {
			i++
			switch c {
			case '"':
				b.WriteString(`\"`)
			case '\\':
				b.WriteString(`\\`)
			case '\b':
				b.WriteString(`\b`)
			case '\t':
				b.WriteString(`\t`)
			case '\n':
				b.WriteString(`\n`)
			case '\f':
				b.WriteString(`\f`)
			case '\r':
				b.WriteString(`\r`)
			default:
				if c >= 0x20 && c <= 0x7e {
					b.WriteByte(c)
				} else {
					encU16(b, uint16(c))
				}
			}
			continue
		}
		r, size := utf8.DecodeRuneInString(s[i:])
		i += size
		if r > 0xffff {
			r -= 0x10000
			encU16(b, uint16(0xd800+(r>>10)))
			encU16(b, uint16(0xdc00+(r&0x3ff)))
		} else {
			encU16(b, uint16(r))
		}
	}
	b.WriteByte('"')
}

func encU16(b *strings.Builder, v uint16) {
	b.WriteString(`\u`)
	b.WriteByte(hexDigits[(v>>12)&0xf])
	b.WriteByte(hexDigits[(v>>8)&0xf])
	b.WriteByte(hexDigits[(v>>4)&0xf])
	b.WriteByte(hexDigits[v&0xf])
}

func encInt(b *strings.Builder, v int) {
	b.WriteString(strconv.Itoa(v))
}

func encBool(b *strings.Builder, v bool) {
	if v {
		b.WriteString("true")
	} else {
		b.WriteString("false")
	}
}

// field writes a comma before every member except the first.  The caller owns
// the braces; *first is the caller's own flag, so a shape with conditional
// members does not have to track commas itself.
func field(b *strings.Builder, first *bool, key string) {
	if *first {
		*first = false
	} else {
		b.WriteByte(',')
	}
	encStr(b, key)
	b.WriteByte(':')
}

func strField(b *strings.Builder, first *bool, key, val string) {
	field(b, first, key)
	encStr(b, val)
}

func intField(b *strings.Builder, first *bool, key string, val int) {
	field(b, first, key)
	encInt(b, val)
}

// optStr is the omit-if-empty rule, in one place so every shape obeys it.
func optStr(b *strings.Builder, first *bool, key, val string) {
	if val != "" {
		strField(b, first, key, val)
	}
}
