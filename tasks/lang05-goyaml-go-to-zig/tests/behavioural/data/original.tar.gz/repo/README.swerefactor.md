# go-yaml -> Zig

This repository is `gopkg.in/yaml.v3` v3.0.1.  Your task is to reimplement it in
Zig, in place, in this same directory.

Read `/workspace/instruction.md` first.  It is the contract: it names the exact
public surface that is graded, the wire protocol your `yaml-probe` must speak,
the parts of the Go library that are explicitly *not* graded, and the rules about
what your submission may and may not contain.  Nothing outside that document is
graded, and everything inside it is.

The Go sources are here on purpose -- they are what you are porting.  So are the
`_test.go` files: they are the most precise description of the behaviour you need
to reproduce, and reading them is expected.  They are not the grading
expectations; those come from running the original library.

`build.zig`, `build.zig.zon` and `src/main.zig` are stubs.  `zig build` succeeds
on this tree and produces `zig-out/bin/yaml-probe`, which prints
`yaml-probe: not implemented` and exits 70.  Everything past that is yours.

`go build ./...` and `go test ./...` work offline; the module cache is already
primed and `go.sum` is already correct, so running the tests does not modify the
tree.  Both `go.mod` and `go.sum` are on the list of files your finished port must
not contain -- delete them at the end, not the start.
