//! Stub.  Builds, runs, and answers nothing.
//!
//! It exists so that `zig build` succeeds on the tree as delivered.  That keeps
//! two failures apart in the grading report: a submission that does not
//! implement the protocol fails the functional cases, and a submission that
//! broke the build fails the build gate.  If this file were absent, State A
//! would fail the build gate, and every "did not build" result afterwards would
//! be ambiguous.
//!
//! Replace it.  See /workspace/instruction.md for the protocol.
const std = @import("std");

pub fn main() !void {
    var buf: [4096]u8 = undefined;
    const stderr = std.io.getStdErr().writer();
    try stderr.writeAll("yaml-probe: not implemented\n");

    // Drain stdin so a harness that writes a request and waits for a line back
    // gets EOF rather than blocking on a full pipe.  A stub that deadlocks the
    // grader would cost a session timeout instead of a clean zero.
    const stdin = std.io.getStdIn().reader();
    while (true) {
        const n = stdin.read(&buf) catch break;
        if (n == 0) break;
    }
    std.process.exit(70);
}
