# The differential probe

`src/probe.js` is not part of JSONata. It is the instrument this repository is
measured through, and it is the one file whose behaviour is a contract rather than
an implementation detail: grading builds this repository and the port beside it,
sends both the same requests, and compares the bytes that come back.

Everything below is that contract. It is long because it is exact -- a port that
matches the library's behaviour and gets the encoding wrong scores nothing, and
that would be a bad way to lose.

Nothing here describes how to implement anything. The probe drives the library's
public API only, and a port that reproduces the library reproduces the probe's
answers for free.

## Transport

NDJSON in, NDJSON out. One request line, one response line, in order.

    probe                        read stdin, write stdout
    probe --batch <in> <out>     read a file, write a file
    probe --selfcheck            reach every op once, exit 0

Both driving modes run the same handler over the same bytes and must produce the
same bytes. They exist separately because expectations are captured to a file and
grading runs over a pipe, and a probe whose two modes disagree has a buffering bug.

Rules the transport has to keep:

* **One line out per line in.** Including for a line that is not JSON: it draws a
  `P0001`. A blank line in the middle of a stream is such a line and is answered;
  a trailing newline at the end of the stream is framing and is not.
* **A response contains no bare newline.** Every string in it goes through the
  escaping in "Strings" below.
* **Each response reaches the far side before the next request is read.** Not
  buffered until exit. A probe that dies on request 300 has already delivered 299
  answers, and the batch is graded on those; a probe that buffers loses all of
  them.
* **The process ends by itself when stdin closes**, having answered everything.
* **Nothing else is written to stdout.** Diagnostics go to stderr, which is not
  compared.

## Requests

A request is a JSON object. `id` is any integer and is echoed back; `op` names the
operation. A field the op does not declare is an error -- `P0006` -- rather than
something to ignore.

| op | required | optional |
| --- | --- | --- |
| `hello` | -- | -- |
| `ast` | `expr` | `recover` |
| `eval` | `expr` | `input`, `bindings`, `options`, `clock`, `repeat` |
| `evalcb` | `expr` | `input`, `bindings`, `options`, `clock`, `repeat` |
| `assign` | `expr`, `assigns` | `input`, `options`, `clock`, `repeat` |
| `register` | `expr`, `funcs` | `input`, `options`, `clock`, `repeat` |

* `expr` -- the JSONata expression, as a string.
* `input` -- the data to evaluate against. **Any JSON value, including `null`.**
  Absent and present-as-`null` are different requests: JSONata distinguishes an
  absent input from a null one, so the probe must too.
* `bindings` -- an object of variable bindings, passed as `evaluate`'s second
  argument.
* `options` -- see "Options".
* `clock` -- `"pinned"` (the default) or `"live"`; see "The clock".
* `repeat` -- an integer 1 to 8, default 1. The expression is evaluated that many
  times **on one compiled expression object**, and every answer is reported. This
  is how per-evaluation state becomes observable.
* `assigns` -- an array of `{"name": string, "value": <any JSON>}`, applied in
  order through `assign` before evaluating.
* `funcs` -- an array of `{"name": string, "impl": string, "signature"?: string |
  null}`, applied in order through `registerFunction`. `impl` names one of the
  implementations in "Fixtures"; an unknown name is `P0009`. `signature` absent
  means the fixture's own; an explicit `null` means register with no signature at
  all.

No request carries code. There is no field whose value is a program, and no way to
reach a function this repository does not name.

`ast` takes `recover` rather than `options` because it is about the parser: with
`recover: true` the parse does not throw on a syntax error and reports diagnostics
instead.

## Responses

    {"id":<int>,"ok":true,"op":"<op>","result":<body>}
    {"id":<int>,"ok":false,"op":"<op>","error":<error>}

Keys in exactly that order. The `op` is echoed so that a response is
self-describing; the id is what pairs it with a request.

A request that fails before its op is known still gets an answer: `id` falls back
to `0` and `op` to `""`. That is the only situation in which either is invented.

Response bodies by op:

* `hello` -- `{"engines":[...],"impls":[...],"ops":[...],"protocol":"..."}`, keys
  in that order, each list sorted. `protocol` is `"jsonata-probe/1"`. It reports
  nothing about the implementation behind it: no version, no runtime, no build
  date. A port answers this identically or it is not answering it.
* `ast` -- `{"ast":<node>,"errors":<node>|null}`. `errors` is `null` when the
  library reports no diagnostics, which covers both a well-formed expression and
  the absence of the `recover` option.
* `eval`, `assign` -- `{"results":[<value>,...]}`, one per repeat.
* `evalcb` -- the same, plus
  `"callbacks":[[{"errNull":<bool>,"resp":<value>},...],...]` -- one inner array
  per repeat, one entry per time the callback was called.
* `register` -- the same as `eval`, plus `"registered":[<name>,...]`.

## Encoding values

A JSONata result is not a JSON value. Four things it can be cannot be spelled in
JSON at all, and every one of them is reachable from an ordinary expression:

| JSONata produces | plain JSON would say | reached by |
| --- | --- | --- |
| `undefined` | the key vanishes | `nope.deeper` |
| `Infinity`, `NaN` | `null` | `1/0`, `0/0` |
| negative zero | `0` | `-(0)`, `$number("-0")` |
| a *sequence* rather than an array | `[...]`, indistinguishably | `a.b` over two matches |

So values are encoded as a two-element array: a one-letter tag and a payload.

| tag | payload | means |
| --- | --- | --- |
| `u` | *absent* -- the array has length 1 | `undefined` |
| `z` | `null` | JSON null |
| `b` | `true` / `false` | boolean |
| `d` | a JSON number, or a string for the four unspellable ones | number |
| `s` | a string | string |
| `a` | an array of encoded values | a plain array |
| `q` | an array of encoded values | a **sequence** |
| `o` | an array of `[key, encoded value]` pairs | object |
| `f` | an object -- see "Callables" | function |
| `x` | a string | a value with no encoding; the string names its kind |

Numbers, precisely:

* `-0` encodes as the string `"-0"`, `Infinity` as `"inf"`, `-Infinity` as
  `"-inf"`, `NaN` as `"nan"`.
* Everything else is the number's own decimal spelling, the shortest that
  round-trips -- `1`, `0.1`, `1e+30`, `1.0715086071862673e+301`. Not padded, not
  reformatted, no trailing `.0`.

Objects keep **insertion order**, which is why they are pairs and not a JSON
object. JSONata's key order is observable through `$keys`, `$each` and `$spread`,
so re-sorting it would hide a real difference.

The `q` tag matters more than it looks. A sequence is what a path expression
returns, it is flattened and unwrapped by rules that are part of the language, and
a port that returns a plain array from `a.b` is wrong in a way no other encoding
would show.

`x` is the escape hatch, and reaching it is a bug in a port rather than a case in
the corpus. It carries the kind of thing that had no tag -- a promise that was
never awaited, a symbol, a class instance -- so that a divergence reads as
"something unencodable arrived here" instead of crashing the process.

### Callables

    {"arity":<int>|null,"kind":"lambda"|"native"|"function","signature":<string>|null}

plus `"thunk":true`, last, when the value is a thunk.

* `kind` is `lambda` for a function defined in JSONata, `native` for one of the
  library's built-ins or a registered implementation, and `function` for a
  callable that is neither.
* `arity` is the number of parameters a lambda declares, from its own parameter
  list. It is `null` for a native: how many parameters a built-in's
  implementation happens to have is a property of the host language, not of
  JSONata, and comparing it across a port would be comparing the two languages.
* `signature` is the signature string as written -- `<n:n>`, `<a<n>:n>` -- or
  `null` when the callable has none.

### Strings

ASCII only, so the transport is byte-identical everywhere:

* Seven short escapes, and only these seven: `\"` `\\` `\b` `\f` `\n` `\r` `\t`.
* Everything else below U+0020, U+007F, and every code point above U+007E, as
  `\uXXXX` with **lowercase** hex. Note what this includes: U+007F has no short
  escape and is escaped, and so is every non-ASCII character, `é` as `é`.
* Iterated by UTF-16 code unit, so an astral character becomes its two surrogates
  and an unpaired surrogate survives as itself.

### AST nodes

The `ast` op reports the tree as ordinary JSON, with three rules:

* **Keys sorted.** The order a parser assigns fields in is a construction trace,
  not behaviour.
* **A key whose value is `undefined` is omitted**, so an absent field and a field
  set to nothing read alike.
* A regular expression becomes `{"$flags":"...","$regex":"..."}`, and a function
  becomes `{"$function":true}`. Both would otherwise serialise to `{}` and make
  every expression containing one indistinguishable.

## Errors

    {"kind":"...", ["cause":"..."], <fields...>, "message":"..."}

`kind` first, `message` last, and in between only the fields that are present, in
this fixed order: `code`, `position`, `token`, `value`, `index`, `type`. `value`
is an encoded value, not raw JSON. There is deliberately no stack trace.

Three kinds:

* `JsonataError` -- the library raised a coded error. `code` is its code (`T2001`,
  `D1011`, `S0207`, ...) and `message` is its message, populated exactly as the
  library populates it, including the interpolated values.
* `ProtocolError` -- the request was not usable. `code` is a `P00NN` from the
  table below, and no library call was made.
* `Panic` -- something failed that had no code: an exception the library did not
  raise itself, a fixture that threw. Carries `cause`, one of a fixed set, and no
  code.

| code | means |
| --- | --- |
| `P0001` | the line is not valid JSON |
| `P0002` | the request is not a JSON object |
| `P0003` | the request has no integer `id` |
| `P0004` | the request has no string `op` |
| `P0005` | unknown op |
| `P0006` | unexpected field |
| `P0007` | field has the wrong type |
| `P0008` | required field is missing |
| `P0009` | unknown fixture name |
| `P0010` | unusable option |

Validation walks the *request's* own key order, so the error names the first
offending field as the request spells it. A request with two problems reports the
one that appears first in the document.

## Options

`options` is passed to the compile step. Four keys are the library's own and go
through untouched:

| key | type |
| --- | --- |
| `recover` | boolean |
| `timeout` | integer, milliseconds |
| `stack` | integer, maximum call depth |
| `sequence` | integer, maximum sequence length |

The fifth, `engine`, is this protocol's stand-in for the library's `RegexEngine`
option, which is a constructor and cannot travel over a wire. A request names one
of the engines in "Fixtures" and the probe translates it: what reaches the library
is `RegexEngine`, and `engine` is not passed on. A key that is in neither list is
`P0006`.

One sharp edge, worth stating because it costs an afternoon to find: what the
library hands a `RegexEngine` constructor is the `RegExp` **object the parser
built**, not a pattern string, and that object already carries the `g` flag. An
engine that rebuilds it must merge flags rather than replace them -- dropping `g`
means `lastIndex` stops advancing and the match iteration never terminates.

## The clock

`$now()`, `$millis()` and `$random()` are shadowed before every evaluation, using
`registerFunction` -- the same route any consumer would take, so a port that
implements `registerFunction` correctly inherits the pinning.

* `$millis()` returns `1700000000000` (2023-11-14T22:13:20.000Z).
* `$now(picture?, timezone?)` formats that instant, delegating to `$fromMillis` so
  that the picture and timezone arguments behave exactly as they do there.
* `$random()` is a `mulberry32` generator seeded with `0x9E3779B9`, re-seeded per
  evaluation. The algorithm is written out in `src/probe-fixtures.js` in exact
  32-bit operations because "a seeded PRNG" is not a specification.

A request may opt out with `"clock":"live"`. Such a response is not compared
against anything -- it cannot be, it carries the wall clock -- and the option
exists so that the pinning is observable rather than assumed.

## Fixtures

Implementations a `register` request may name, and regex engines an `engine`
option may name. They are the closed vocabulary that lets a case exercise
registered functions without any code on the wire. `hello` reports both lists;
`src/probe-fixtures.js` is the definition.

Implementations: `double`, `concat2`, `describe`, `throwing`, `throwingCode`,
`focusInput`, `focusLookup`, `asyncDouble`, `makeAdder`, `counter`, `nothing`,
`hostDate`, `hostMap`.

Engines: `native`, `caseless`, `nomatch`, `broken`.

Four of these carry a requirement that is easy to miss:

* `focusInput` and `focusLookup` read `this.input` and
  `this.environment.lookup`. A registered function is called with the evaluation
  focus as its receiver, and a port that loses that binding fails both.
* `asyncDouble` returns a promise. The library awaits it, so the answer is the
  resolved value -- a port that reports the promise itself encodes an `x`.
* `counter` holds state across calls within one registration, and is rebuilt per
  registration rather than shared between them.
* `hostDate` and `hostMap` return objects the library has no type for. It passes
  them through untouched, and they are the only values in reach of the `x` tag:
  nothing an expression can write produces one. What the library does *around*
  such a value is not uniform, so it is worth stating rather than assuming --
  `$type` says `object` for both, `$boolean` is false for both, `$count` is 1,
  `$keys` is undefined, and `$string` differs between them.

## The build

`npm run build` produces `dist/`, and `dist/` is what is graded:

* `dist/probe.js` -- run as `node dist/probe.js`, answers the protocol above.
* `dist/jsonata.js` -- the library, requirable, exporting the callable
  `jsonata` as `module.exports` itself.
* `dist/jsonata.d.ts` -- the type declarations for that export.

No network at any point, and no dependency needs installing for the build to run.

## The type surface

`jsonata.d.ts` in the repository root is the published type surface: a callable
`jsonata` merged with a namespace holding `JsonataOptions`, `Expression`,
`ExprNode`, `JsonataError`, `Environment` and `Focus`, exported with `export =`.
It is hand-maintained today because the implementation is JavaScript.

Whatever the implementation becomes, `dist/jsonata.d.ts` has to keep describing
that surface, because it is what a consumer of this package compiles against. What
that means in practice, stated as the properties a consumer relies on:

* `import jsonata = require('jsonata')` yields the callable itself, and
  `jsonata.Expression`, `jsonata.JsonataOptions`, `jsonata.Focus`,
  `jsonata.JsonataError` and `jsonata.ExprNode` are all nameable as types
  through it.
* `jsonata(expr, options?)` takes a **string** first argument. A number is a type
  error, not a runtime surprise.
* `JsonataOptions` is a **closed** object type over the five documented keys, each
  with its own type. An unrecognised key is a type error, and `recover: "yes"` is
  a type error.
* `evaluate(input, bindings?)` returns a promise. The three-argument form taking a
  callback returns nothing.
* `assign`, `registerFunction`, `ast` and `errors` are all present, and
  `registerFunction`'s implementation parameter is typed with `this` as the
  evaluation focus, so `this.input` and `this.environment` resolve inside it.
* `errors()` is callable and returns the diagnostics of a `recover: true` parse,
  or undefined for an expression that parsed cleanly. Upstream's own copy of the
  declarations omits it, which is an omission rather than a decision --
  `src/probe.js` calls it, and a declaration that omits it cannot describe the
  module the probe compiles against. The file here has it.

The declarations have to describe the module that is actually shipped, not an
aspiration: a consumer that compiles against `dist/jsonata.d.ts` and then requires
`dist/jsonata.js` gets the behaviour the declarations promised.
