'use strict';
/**
 * The wire format: how a JSONata value becomes bytes.
 *
 * This file is the reason the probe cannot be written with `JSON.stringify`, and
 * the reason it is worth reading before porting anything.  JSONata evaluates to
 * JavaScript values, and four of the things it can produce have no JSON spelling
 * at all:
 *
 *   - `undefined`, which is JSONata's "no match" and is not the same answer as
 *     `null`.  `JSON.stringify(undefined)` is the string `undefined`, not JSON.
 *   - `Infinity`, `-Infinity` and `NaN`, all reachable (`1/0`, `-1/0`, `0/0`,
 *     `1e308*10`, and a `1e309` that arrives in the input document).
 *     `JSON.stringify` renders all three as `null`, which is a *different
 *     JSONata value*.
 *   - `-0`, reachable through `-(0)` and `$number("-0")`, and rendered by
 *     `JSON.stringify` as `0`.
 *   - the sequence flag.  `a.b` over two matches returns an array carrying
 *     `sequence === true`; the same array without the flag behaves differently
 *     when it is fed back into an expression.  It is observable through the
 *     public API and it does not survive a plain serialisation.
 *
 * So every value is written as a two-element tagged array, `[tag, payload]`, and
 * the tag says which of those things it is.  The tags are:
 *
 *   ["u"]                     undefined
 *   ["z",null]                null
 *   ["b",true|false]          boolean
 *   ["d",<number>]            a finite number other than -0
 *   ["d","inf"|"-inf"|"nan"|"-0"]   the four numbers JSON cannot spell
 *   ["s",<string>]            string
 *   ["a",[<value>...]]        array without the sequence flag
 *   ["q",[<value>...]]        array with `sequence === true`
 *   ["o",[[<key>,<value>]...]] object, in `Object.keys` order
 *   ["f",{...}]               something callable; see encodeCallable
 *   ["x",<string>]            anything else, named by its constructor
 *
 * Objects are pairs rather than a JSON object for two reasons.  Key order is
 * observable in JSONata -- `$keys`, `$each` and `$spread` all report insertion
 * order, and a re-emitted object preserves it -- and a JSON object with a key
 * named `u` would otherwise be indistinguishable from a tag.  Pairs make the
 * order explicit and the encoding total.
 *
 * Strings are emitted ASCII-only, with lowercase hex in every `\uXXXX`.  That is
 * a deliberate constraint rather than an accident of a library: it makes the
 * expected output diffable in a terminal, and it means a port cannot pass by
 * delegating to a serialiser whose escaping policy happens to differ.  Iteration
 * is by UTF-16 code unit, so an unpaired surrogate is escaped as itself instead
 * of being replaced.
 */

var HEX = '0123456789abcdef';

/** `\uXXXX` for one code unit, lowercase hex, always four digits. */
function u4(code) {
    return '\\u' + HEX[(code >> 12) & 0xf] + HEX[(code >> 8) & 0xf] +
        HEX[(code >> 4) & 0xf] + HEX[code & 0xf];
}

/**
 * One JSON string literal, quotes included, ASCII only.
 *
 * The seven short escapes are the ones JSON names; everything else below 0x20
 * and everything above 0x7e goes through `u4`.  `/` is deliberately not escaped
 * and `` deliberately is -- DEL is not printable, and leaving it raw makes
 * a transcript that cannot be read in a terminal.
 */
function encodeString(value) {
    var out = '"';
    for (var i = 0; i < value.length; i++) {
        var code = value.charCodeAt(i);
        if (code === 0x22) { out += '\\"'; }
        else if (code === 0x5c) { out += '\\\\'; }
        else if (code === 0x08) { out += '\\b'; }
        else if (code === 0x0c) { out += '\\f'; }
        else if (code === 0x0a) { out += '\\n'; }
        else if (code === 0x0d) { out += '\\r'; }
        else if (code === 0x09) { out += '\\t'; }
        else if (code < 0x20 || code > 0x7e) { out += u4(code); }
        else { out += value.charAt(i); }
    }
    return out + '"';
}

/**
 * One number, as the shortest decimal that reads back as itself.
 *
 * `String(n)` is that shortest form in ECMAScript, and it is what JSON uses for
 * every finite number except the four this returns as tagged strings instead.
 * `-0` has to be caught with `Object.is`: `-0 === 0` is true, and `String(-0)` is
 * `"0"`, so a comparison and a stringification both lose it.
 */
function encodeNumber(value) {
    if (Object.is(value, -0)) { return '"-0"'; }
    if (value === Infinity) { return '"inf"'; }
    if (value === -Infinity) { return '"-inf"'; }
    if (value !== value) { return '"nan"'; }   // NaN
    return String(value);
}

/**
 * What a callable is, without saying how it was made.
 *
 * JSONata has four callable shapes and the difference between them is public:
 *
 *   - a lambda, `function($x){...}`, which is an *object* carrying
 *     `_jsonata_lambda: true` and a circular reference to its own environment
 *     (so `JSON.stringify` on one throws);
 *   - a built-in or registered function, an object carrying
 *     `_jsonata_function: true` and its signature;
 *   - a plain JavaScript function, which is what a bound value and a compiled
 *     regex matcher both are;
 *   - a partially applied procedure, which is a lambda with `?` arguments.
 *
 * `arity` is the number of declared parameters, taken from the lambda's own
 * argument list rather than from `Function.prototype.length`, because that
 * property is a fact about how the implementation happened to write the wrapper.
 * A native function reports `null` for the same reason.
 *
 * `signature` is the declared signature string when there is one -- `<n:n>` and
 * friends -- because a registered function's signature is part of what a caller
 * observes: it decides which arguments are rejected and with which code.
 */
function encodeCallable(value) {
    var lambda = value && value._jsonata_lambda === true;
    var native = value && value._jsonata_function === true;
    var signature = null;
    if (value && value.signature && typeof value.signature.definition === 'string') {
        signature = value.signature.definition;
    }
    var arity = null;
    if (lambda && Array.isArray(value.arguments)) { arity = value.arguments.length; }
    var out = '{"arity":' + (arity === null ? 'null' : String(arity)) +
        ',"kind":' + encodeString(lambda ? 'lambda' : (native ? 'native' : 'function')) +
        ',"signature":' + (signature === null ? 'null' : encodeString(signature));
    if (lambda && value.thunk === true) { out += ',"thunk":true'; }
    return out + '}';
}

/** Whether a value is one of the four callable shapes above. */
function isCallable(value) {
    if (typeof value === 'function') { return true; }
    return !!value && typeof value === 'object' &&
        (value._jsonata_lambda === true || value._jsonata_function === true);
}

/**
 * One JSONata value as wire text.  Total: every input produces a tag.
 *
 * The `x` tag is the escape hatch and it is deliberately uninformative -- it
 * carries a constructor name and nothing else.  Nothing in the corpus reaches it
 * (the probe's own bindings decide what non-JSON values can enter an evaluation,
 * and they bind none), so a submission that produces one has returned something
 * this protocol has no spelling for, and the tag says which kind without
 * inventing a serialisation for it.
 */
function encodeValue(value) {
    if (value === undefined) { return '["u"]'; }
    if (value === null) { return '["z",null]'; }
    var type = typeof value;
    if (type === 'boolean') { return '["b",' + (value ? 'true' : 'false') + ']'; }
    if (type === 'number') { return '["d",' + encodeNumber(value) + ']'; }
    if (type === 'string') { return '["s",' + encodeString(value) + ']'; }
    if (isCallable(value)) { return '["f",' + encodeCallable(value) + ']'; }
    if (Array.isArray(value)) {
        var items = [];
        for (var i = 0; i < value.length; i++) { items.push(encodeValue(value[i])); }
        return '["' + (value.sequence === true ? 'q' : 'a') + '",[' +
            items.join(',') + ']]';
    }
    if (type === 'object') {
        var proto = Object.getPrototypeOf(value);
        if (proto === Object.prototype || proto === null) {
            var keys = Object.keys(value);
            var pairs = [];
            for (var k = 0; k < keys.length; k++) {
                pairs.push('[' + encodeString(keys[k]) + ',' +
                    encodeValue(value[keys[k]]) + ']');
            }
            return '["o",[' + pairs.join(',') + ']]';
        }
        var name = (proto && proto.constructor && proto.constructor.name) || 'object';
        return '["x",' + encodeString(String(name)) + ']';
    }
    return '["x",' + encodeString(type) + ']';
}

/**
 * One AST node, or one parse-error record, as wire text.
 *
 * A different encoder from `encodeValue`, because an AST is a different kind of
 * thing.  Its shape is a published part of the API -- `expression.ast()` returns
 * it and `ExprNode` in the type surface describes it -- but the *order* its keys
 * were assigned in is not: that is a trace of how the parser happened to build
 * the node.  So keys are sorted here, which turns the AST into a value rather
 * than a construction log, and it means a port that assembles a node in a
 * different order is not failed for it.
 *
 * Three things get special treatment:
 *
 *   - `undefined`-valued properties are omitted.  The parser leaves some keys
 *     present-but-undefined (`token` on an S0500, `type` on some errors), and a
 *     port that never creates the key at all is not doing anything different.
 *   - a `RegExp` becomes `{"$regex":<source>,"$flags":<flags>}`.  Regex literals
 *     appear in the AST as native `RegExp` objects, which serialise to `{}` and
 *     would make every regex expression indistinguishable from every other.
 *   - a function becomes `{"$function":true}`.  Nothing in a parsed AST should be
 *     callable; the case is here so that a submission that puts one there
 *     produces a legible difference rather than a crash in the encoder.
 */
function encodeNode(node) {
    if (node === undefined) { return 'null'; }
    if (node === null) { return 'null'; }
    var type = typeof node;
    if (type === 'boolean') { return node ? 'true' : 'false'; }
    if (type === 'string') { return encodeString(node); }
    if (type === 'number') { return encodeNumber(node); }
    if (type === 'function') { return '{"$function":true}'; }
    if (Array.isArray(node)) {
        var items = [];
        for (var i = 0; i < node.length; i++) { items.push(encodeNode(node[i])); }
        return '[' + items.join(',') + ']';
    }
    if (type === 'object') {
        if (node instanceof RegExp) {
            return '{"$flags":' + encodeString(node.flags) +
                ',"$regex":' + encodeString(node.source) + '}';
        }
        var keys = Object.keys(node).sort();
        var pairs = [];
        for (var k = 0; k < keys.length; k++) {
            if (node[keys[k]] === undefined) { continue; }
            pairs.push(encodeString(keys[k]) + ':' + encodeNode(node[keys[k]]));
        }
        return '{' + pairs.join(',') + '}';
    }
    return encodeString(type);
}

// The fields a JSONata error carries, in the order they are written on the wire.
// Fixed and explicit, rather than "whatever keys the object has sorted": the set
// varies by code (an S0500 has no token, a T0412 has `value` and `index`), and a
// port that attaches a key with an undefined value should not be distinguishable
// from one that omits it.  `stack` is deliberately absent -- it is a list of file
// paths from the machine that produced it.
var ERROR_FIELDS = ['code', 'position', 'token', 'value', 'index', 'type'];

/**
 * One error as wire text: `{"kind":...,"message":...,<fields>}`.
 *
 * `kind` is the three-way split the protocol publishes:
 *
 *   - `JsonataError` -- the error carries a `code`.  Everything JSONata itself
 *     reports, parse and evaluation alike.
 *   - `ProtocolError` -- this probe rejected the request.  Never produced by
 *     JSONata; see `PROTOCOL_CODES` in probe.js.
 *   - `Panic` -- something threw that was not a JSONata error: a registered
 *     function that raised, a regex engine whose constructor failed.  `cause` is
 *     a normalised token from a declared set rather than a class name, because a
 *     class name is a fact about the runtime rather than about the failure.
 *
 * `value` goes through `encodeValue`, not `encodeNode`: it is a JSONata value
 * (T0412 reports the offending argument), so it can be `undefined`, a sequence,
 * or a number JSON cannot spell.
 *
 * `message` is present when there is one and absent when there is not, rather
 * than appearing as `""`.  A JsonataError and a ProtocolError always have one --
 * from JSONata's error table and from `PROTOCOL_CODES` respectively, both data in
 * this repository.  A Panic has one only when the fixtures wrote it; see
 * `classifyThrown`.  Emitting an empty string for the rest would put a field on
 * the wire that says nothing and still has to be reproduced.
 */
function encodeError(err) {
    var parts = ['"kind":' + encodeString(err.kind)];
    if (err.cause !== undefined) { parts.push('"cause":' + encodeString(err.cause)); }
    for (var i = 0; i < ERROR_FIELDS.length; i++) {
        var name = ERROR_FIELDS[i];
        if (!(name in err) || err[name] === undefined) { continue; }
        if (name === 'value') { parts.push('"value":' + encodeValue(err.value)); }
        else if (name === 'position' || name === 'index') {
            parts.push('"' + name + '":' + encodeNode(err[name]));
        } else { parts.push('"' + name + '":' + encodeNode(err[name])); }
    }
    if (err.message !== undefined) {
        parts.push('"message":' + encodeString(String(err.message)));
    }
    return '{' + parts.join(',') + '}';
}

/**
 * One response line, without its newline.
 *
 * `id` first, then `ok`, then `op`, then exactly one of `result` and `error`.
 * The order is fixed because the comparison is on bytes: a port that emits the
 * same fields in a different order has produced a different line, and saying so
 * here is what makes that a contract rather than a surprise.
 */
function encodeResponse(id, op, ok, body) {
    var out = '{"id":' + encodeNode(id) + ',"ok":' + (ok ? 'true' : 'false') +
        ',"op":' + encodeString(op) + ',';
    out += ok ? ('"result":' + body) : ('"error":' + body);
    return out + '}';
}

module.exports = {
    encodeCallable: encodeCallable,
    encodeError: encodeError,
    encodeNode: encodeNode,
    encodeNumber: encodeNumber,
    encodeResponse: encodeResponse,
    encodeString: encodeString,
    encodeValue: encodeValue,
    isCallable: isCallable
};
