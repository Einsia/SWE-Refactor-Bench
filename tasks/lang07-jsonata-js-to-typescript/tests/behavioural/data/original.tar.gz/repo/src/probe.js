'use strict';
/**
 * The differential probe: one JSON request per line in, one JSON response per
 * line out.
 *
 * This is the instrument the whole task is measured through.  It is not a test
 * suite and it asserts nothing: it drives the library's *public* API -- the
 * callable `jsonata` export, `evaluate`, `assign`, `registerFunction`, `ast`,
 * `errors`, and the five documented options -- and reports what came back, byte
 * for byte.  Whether an answer is right is decided by comparing two probes, never
 * by anything in this file.
 *
 * Transport
 * ---------
 * NDJSON both ways.  One line in is exactly one line out, in order, and a
 * response never contains a bare newline: every string it emits goes through
 * `encodeString`, which escapes control characters.  A reader can therefore split
 * the output on `\n` and get one response per line, which is what makes a crash
 * attributable to the request that caused it rather than voiding the batch.
 *
 * Each response is written with a blocking write before the next request is read,
 * so a probe that dies on request 300 has already delivered 299 answers.  That
 * costs a busy-wait on EAGAIN (see `writeAll`) and buys crash localisation.
 *
 * Two invocations:
 *
 *   probe.js                        read stdin, write stdout   ("serve")
 *   probe.js --batch <in> <out>     read a file, write a file
 *
 * Both drive the same handler, and both must produce the same bytes for the same
 * requests: `--batch <in> <out>` writes to its file exactly what stdin writes to
 * stdout, framing included.  Two modes exist because a file is re-readable and a
 * pipe is not, and they are required to agree because the difference between them
 * is where a flushing bug lives -- answers accumulated and written on exit lose
 * their tail in a file, and nothing over a pipe can see that, because the reader
 * drains to EOF after the process is gone.
 *
 * Determinism
 * -----------
 * `$now()`, `$millis()` and `$random()` are shadowed before every evaluation with
 * fixed-value implementations, through the same `registerFunction` a consumer
 * would use.  Without that, three built-ins would be unanswerable: the frozen
 * expectation would carry the clock reading from the moment the image was built.
 * A request may opt out with `"clock":"live"`, and such a response is not
 * compared -- see the probe contract.
 *
 * What is deliberately absent
 * ---------------------------
 * No request carries code.  There is no field whose value is JavaScript to be
 * evaluated, and no way to reach a function this file did not name: the
 * implementations and regex engines a case can ask for live in
 * `probe-fixtures.js` under fixed names, and an unknown name is a ProtocolError.
 */

var fs = require('fs');
var jsonata = require('./jsonata');
var wire = require('./probe-wire');
var fixtures = require('./probe-fixtures');

var PROTOCOL_VERSION = 'jsonata-probe/1';

// The ops, and the fields each accepts.  `!` marks a required field; `any` means
// any JSON value, so that a present-but-null `input` stays distinguishable from
// an absent one (JSONata evaluates `null` and `undefined` differently).
//
// The table is the validator.  A field this table does not list is a
// ProtocolError rather than a silently ignored key, because a submission that
// ignores an unexpected field would pass a case whose whole subject is that the
// field was rejected.
var OP_FIELDS = {
    'hello': {},
    'ast': { expr: 'string!', recover: 'boolean' },
    'eval': {
        expr: 'string!', input: 'any', bindings: 'object', options: 'object',
        clock: 'string', repeat: 'integer'
    },
    'evalcb': {
        expr: 'string!', input: 'any', bindings: 'object', options: 'object',
        clock: 'string', repeat: 'integer'
    },
    'assign': {
        expr: 'string!', input: 'any', options: 'object', clock: 'string',
        repeat: 'integer', assigns: 'array!'
    },
    'register': {
        expr: 'string!', input: 'any', options: 'object', clock: 'string',
        repeat: 'integer', funcs: 'array!'
    }
};

// The keys `options` may carry.  Four are JSONata's own; `engine` is this
// protocol's stand-in for `RegexEngine`, which is a constructor and cannot travel
// over a wire, so a case names one of `probe-fixtures.engineNames()` instead.
var OPTION_TYPES = {
    recover: 'boolean', timeout: 'integer', stack: 'integer',
    sequence: 'integer', engine: 'string'
};

// Protocol failures, by code.  Codes rather than prose because the corpus asserts
// on them: a message can be reworded, and `P0006` cannot.
var PROTOCOL_CODES = {
    P0001: 'the line is not valid JSON',
    P0002: 'the request is not a JSON object',
    P0003: 'the request has no integer `id`',
    P0004: 'the request has no string `op`',
    P0005: 'unknown op',
    P0006: 'unexpected field',
    P0007: 'field has the wrong type',
    P0008: 'required field is missing',
    P0009: 'unknown fixture name',
    P0010: 'unusable option'
};

/** A ProtocolError, ready for `wire.encodeError`. */
function protocolError(code, detail) {
    return {
        kind: 'ProtocolError',
        code: code,
        message: PROTOCOL_CODES[code] + (detail ? ': ' + detail : '')
    };
}

/**
 * Whatever was thrown, classified.
 *
 * A JSONata error is an object with a `code`; everything else is a Panic.  The
 * split is on the presence of that field rather than on a class, because JSONata
 * throws plain objects rather than Error instances, and because a registered
 * function is free to throw either kind -- `throwingCode` in the fixtures throws
 * a coded object and is reported as a JsonataError, which is the behaviour.
 *
 * `cause` on a Panic is a normalised token, not a class name: the class of a
 * thrown value is a fact about the runtime that threw it.
 *
 * A Panic's *message* is dropped for the same reason, unless the fixtures wrote
 * it.  `fixtures.authoredError` marks the ones they did; everything else reaching
 * this path threw with a sentence V8 composed about its own failure, naming the
 * value and the property it happened to be handed, and a response carrying that
 * would make the engine underneath the port part of the answer.  A JsonataError
 * keeps its message: those come from JSONata's own error table, which is a data
 * table in the tree being ported and not the runtime's prose.
 */
function classifyThrown(err) {
    if (err && typeof err === 'object' && typeof err.code === 'string') {
        var out = { kind: 'JsonataError', message: err.message };
        var names = ['code', 'position', 'token', 'value', 'index', 'type'];
        for (var i = 0; i < names.length; i++) {
            if (names[i] in err) { out[names[i]] = err[names[i]]; }
        }
        return out;
    }
    var panic = { kind: 'Panic', cause: panicCause(err) };
    if (err && typeof err === 'object' && err[fixtures.AUTHORED] === true) {
        panic.message = String(err.message);
    }
    return panic;
}

/**
 * The declared cause tokens.  Closed set, and the freeze refuses an expectation
 * carrying anything else -- an unclassified panic is a diagnostic nobody declared.
 *
 * `stack-overflow` is listed and is *excluded from the corpus*: the depth at which
 * a runtime exhausts its stack is a property of the runtime, so a case that
 * depended on it would be measuring the machine.
 */
function panicCause(err) {
    if (err instanceof RangeError) {
        var message = String(err.message || '');
        if (message.indexOf('call stack') >= 0) { return 'stack-overflow'; }
        return 'range';
    }
    if (err instanceof TypeError) { return 'type'; }
    if (err instanceof SyntaxError) { return 'syntax'; }
    if (err instanceof Error) { return 'error'; }
    if (err === null || err === undefined) { return 'nonvalue'; }
    return 'thrown-' + typeof err;
}

// -- request validation -----------------------------------------------------

/** Whether `value` satisfies one of the type names used in the tables above. */
function typeOk(value, want) {
    switch (want) {
    case 'any': return true;
    case 'string': return typeof value === 'string';
    case 'boolean': return typeof value === 'boolean';
    case 'integer':
        return typeof value === 'number' && isFinite(value) &&
            Math.floor(value) === value;
    case 'array': return Array.isArray(value);
    case 'object':
        return value !== null && typeof value === 'object' && !Array.isArray(value);
    default: return false;
    }
}

/**
 * Check one request against `OP_FIELDS`.  Returns a ProtocolError or null.
 *
 * Fields are checked in the order they appear in the *request*, not in the order
 * the table lists them, so the error names the first offending field in document
 * order.  That makes the diagnostic reproducible from reading the line, which a
 * table-ordered check does not: two unexpected fields would otherwise be reported
 * in whichever order the table happened to be written.
 */
function validate(request) {
    var spec = OP_FIELDS[request.op];
    var keys = Object.keys(request);
    var i;
    for (i = 0; i < keys.length; i++) {
        var key = keys[i];
        if (key === 'id' || key === 'op') { continue; }
        if (!Object.prototype.hasOwnProperty.call(spec, key)) {
            return protocolError('P0006', '`' + key + '` is not a field of op `' +
                request.op + '`');
        }
        var want = spec[key].replace('!', '');
        if (!typeOk(request[key], want)) {
            return protocolError('P0007', '`' + key + '` must be ' + want);
        }
    }
    var names = Object.keys(spec);
    for (i = 0; i < names.length; i++) {
        if (spec[names[i]].charAt(spec[names[i]].length - 1) !== '!') { continue; }
        if (!Object.prototype.hasOwnProperty.call(request, names[i])) {
            return protocolError('P0008', '`' + names[i] + '` is required by op `' +
                request.op + '`');
        }
    }
    if ('clock' in request && request.clock !== 'pinned' && request.clock !== 'live') {
        return protocolError('P0007', '`clock` must be "pinned" or "live"');
    }
    if ('repeat' in request && (request.repeat < 1 || request.repeat > 8)) {
        return protocolError('P0007', '`repeat` must be between 1 and 8');
    }
    if ('options' in request) {
        var opts = Object.keys(request.options);
        for (i = 0; i < opts.length; i++) {
            var name = opts[i];
            if (!Object.prototype.hasOwnProperty.call(OPTION_TYPES, name)) {
                return protocolError('P0006', '`options.' + name + '` is not an option');
            }
            if (!typeOk(request.options[name], OPTION_TYPES[name])) {
                return protocolError('P0007', '`options.' + name + '` must be ' +
                    OPTION_TYPES[name]);
            }
        }
        if ('engine' in request.options &&
            fixtures.engineFor(request.options.engine) === null) {
            return protocolError('P0009', 'no regex engine named `' +
                request.options.engine + '`; known: ' +
                fixtures.engineNames().join(', '));
        }
    }
    if (request.op === 'assign') {
        for (i = 0; i < request.assigns.length; i++) {
            var entry = request.assigns[i];
            if (!typeOk(entry, 'object')) {
                return protocolError('P0007', 'assigns[' + i + '] must be object');
            }
            if (typeof entry.name !== 'string') {
                return protocolError('P0008', 'assigns[' + i + '].name is required');
            }
            if (!('value' in entry)) {
                return protocolError('P0008', 'assigns[' + i + '].value is required');
            }
            var extra = Object.keys(entry).filter(function (k) {
                return k !== 'name' && k !== 'value';
            });
            if (extra.length) {
                return protocolError('P0006', 'assigns[' + i + '].' + extra[0]);
            }
        }
    }
    if (request.op === 'register') {
        for (i = 0; i < request.funcs.length; i++) {
            var fn = request.funcs[i];
            if (!typeOk(fn, 'object')) {
                return protocolError('P0007', 'funcs[' + i + '] must be object');
            }
            if (typeof fn.name !== 'string') {
                return protocolError('P0008', 'funcs[' + i + '].name is required');
            }
            if (typeof fn.impl !== 'string') {
                return protocolError('P0008', 'funcs[' + i + '].impl is required');
            }
            if ('signature' in fn && typeof fn.signature !== 'string' &&
                fn.signature !== null) {
                return protocolError('P0007', 'funcs[' + i + '].signature must be string or null');
            }
            var extraF = Object.keys(fn).filter(function (k) {
                return k !== 'name' && k !== 'impl' && k !== 'signature';
            });
            if (extraF.length) {
                return protocolError('P0006', 'funcs[' + i + '].' + extraF[0]);
            }
            if (fixtures.implFor(fn.impl) === null) {
                return protocolError('P0009', 'no implementation named `' + fn.impl +
                    '`; known: ' + fixtures.implNames().join(', '));
            }
        }
    }
    return null;
}

/**
 * The options object handed to `jsonata()`.
 *
 * `engine` is translated to `RegexEngine` here and removed, so that what reaches
 * the library is exactly the documented option set.  A port that passed `engine`
 * straight through would be handing JSONata an option it does not have.
 */
function buildOptions(raw) {
    if (!raw) { return undefined; }
    var out = {};
    var keys = Object.keys(raw);
    var any = false;
    for (var i = 0; i < keys.length; i++) {
        var key = keys[i];
        if (key === 'engine') {
            out.RegexEngine = fixtures.engineFor(raw.engine);
        } else {
            out[key] = raw[key];
        }
        any = true;
    }
    return any ? out : undefined;
}

/**
 * Shadow the three non-deterministic built-ins on one compiled expression.
 *
 * Through `registerFunction`, which is the public route a consumer would take, so
 * this is not a privileged hook: a port that implements `registerFunction`
 * correctly gets the pinning for free, and one that does not fails these cases
 * and the `register` family together.
 *
 * `$now` delegates to `$fromMillis` by evaluating a small expression, so this file
 * does not reach into the datetime module.  The picture and timezone arguments are
 * threaded through, which is what makes `$now("[H01]:[m01]")` answerable.
 */
function pinClock(expression) {
    var fixed = fixtures.FIXED_MILLIS;
    expression.registerFunction('millis', function () { return fixed; }, '<:n>');
    var random = fixtures.mulberry32(fixtures.RANDOM_SEED);
    expression.registerFunction('random', function () { return random(); }, '<:n>');
    expression.registerFunction('now', function (picture, timezone) {
        var inner = jsonata('$fromMillis($m, $p, $z)');
        return inner.evaluate({}, { m: fixed, p: picture, z: timezone });
    }, '<s?s?:s>');
}

// -- the ops ----------------------------------------------------------------

/**
 * `hello`: the handshake.
 *
 * Reports the protocol version and the three closed vocabularies a case may draw
 * from -- the ops, the registerable implementations and the regex engines.  It
 * deliberately reports nothing about the implementation behind it: no version, no
 * runtime, no build date.  A response that named those would let a submission
 * discover which side of a differential it is, and it would make the handshake
 * unanswerable by a port that is otherwise correct.
 */
function opHello() {
    return '{"engines":[' + fixtures.engineNames().map(wire.encodeString).join(',') +
        '],"impls":[' + fixtures.implNames().map(wire.encodeString).join(',') +
        '],"ops":[' + Object.keys(OP_FIELDS).sort().map(wire.encodeString).join(',') +
        '],"protocol":' + wire.encodeString(PROTOCOL_VERSION) + '}';
}

/**
 * `ast`: compile and report the tree, without evaluating.
 *
 * With `recover: true` the parser does not throw on a syntax error; it returns a
 * tree with `error` nodes in it and a list of diagnostics from `errors()`.  Both
 * halves are reported, because the recovery path is a documented option and the
 * shape of a recovered tree is the only way to observe it.
 *
 * `errors` is `null` when `errors()` returns undefined, which is what happens both
 * without the option and with it when the expression was in fact well-formed.  The
 * two are the same observation -- there were no diagnostics -- and are reported
 * the same way.
 *
 * Every field of a diagnostic is published except `stack`, which is dropped by
 * `stripStacks` -- see there for why.
 */
function opAst(request) {
    var options = request.recover ? { recover: true } : undefined;
    var expression = jsonata(request.expr, options);
    var errors = expression.errors();
    return '{"ast":' + wire.encodeNode(expression.ast()) +
        ',"errors":' +
        (errors === undefined ? 'null' : wire.encodeNode(stripStacks(errors))) + '}';
}

/**
 * Remove every `stack` property, at any depth, from a diagnostic payload.
 *
 * The parser attaches `stack: (new Error()).stack` to the errors it recovers from
 * -- 89 places do it.  A V8 stack is three unportable things at once: the absolute
 * path of every frame's file, the line and column of every frame, and whether V8
 * chose to label a frame `async`.  So a graded answer containing one is not a
 * question about JSONata that any port can answer: it names the files and line
 * numbers of the implementation that produced it, and the first two would differ
 * for a port even if it were otherwise byte-perfect.  It also puts the build
 * machine's directory layout into an expectation file that ships in the image.
 *
 * This is not a new policy.  `ERROR_FIELDS` in `probe-wire.js` already excludes
 * `stack` for thrown errors, for this reason, in those words; the recovery path
 * simply never applied it, because it publishes the diagnostic objects directly
 * rather than through that list.  This makes the two agree.
 *
 * Dropping the one field, rather than allowlisting the fields kept the way
 * `ERROR_FIELDS` does, is deliberate.  That list defines the probe's own diagnostic
 * vocabulary for a thrown error, where the probe chooses the shape.  `errors()` is
 * JSONata's published API and reproducing it faithfully is the thing being measured,
 * so an allowlist here would mean a field upstream adds later silently stops being
 * graded.  Dropping exactly one field leaves every other one graded, and if some
 * future field turns out to be unportable too, the build-time identity run is what
 * says so: it is what caught this one, by answering one request in two processes and
 * getting two answers.
 *
 * Only plain objects are rebuilt.  A `RegExp` is `typeof 'object'` with no own
 * enumerable keys, so treating it as one would encode it as `{}` and quietly lose a
 * pattern; `encodeNode` has a case for it and must still receive the instance.  Key
 * order is not a correctness concern here because `encodeNode` sorts an object's
 * keys, but the rebuild preserves insertion order anyway, since `Object.keys` yields
 * it.
 */
function stripStacks(value) {
    if (Array.isArray(value)) { return value.map(stripStacks); }
    if (value === null || typeof value !== 'object') { return value; }
    if (Object.getPrototypeOf(value) !== Object.prototype) { return value; }
    var out = {};
    var keys = Object.keys(value);
    for (var i = 0; i < keys.length; i++) {
        if (keys[i] === 'stack') { continue; }
        out[keys[i]] = stripStacks(value[keys[i]]);
    }
    return out;
}

/**
 * The shared body of `eval`, `evalcb`, `assign` and `register`.
 *
 * One function because the four differ only in what they do to the compiled
 * expression before evaluating it, and in whether they observe the callback.
 * Splitting them would mean four copies of the repeat loop and the clock pinning,
 * and a divergence between them would be invisible.
 *
 * `repeat` runs the same expression against the same input more than once, on one
 * compiled expression, and reports every answer.  That is how per-evaluation state
 * becomes observable: an assignment made by `assign` must survive into the second
 * call, a `counter` fixture must count, and a pinned `$millis()` must return the
 * same value both times.  A port that rebuilds its environment per `evaluate` call
 * passes `repeat: 1` everywhere and fails here.
 */
async function evaluateOp(request) {
    var expression = jsonata(request.expr, buildOptions(request.options));
    if (request.clock !== 'live') { pinClock(expression); }

    var registered = [];
    if (request.op === 'register') {
        for (var f = 0; f < request.funcs.length; f++) {
            var spec = request.funcs[f];
            var pair = fixtures.implFor(spec.impl);
            // An explicit `signature` in the request wins, including an explicit
            // null meaning "register with no signature at all".  Absent means the
            // fixture's own.
            var signature = 'signature' in spec ? spec.signature : pair[1];
            if (signature === null) {
                expression.registerFunction(spec.name, pair[0]);
            } else {
                expression.registerFunction(spec.name, pair[0], signature);
            }
            registered.push(spec.name);
        }
    }
    if (request.op === 'assign') {
        for (var a = 0; a < request.assigns.length; a++) {
            expression.assign(request.assigns[a].name, request.assigns[a].value);
        }
    }

    var repeat = 'repeat' in request ? request.repeat : 1;
    var input = 'input' in request ? request.input : undefined;
    var bindings = 'bindings' in request ? request.bindings : undefined;
    var results = [];
    var callbacks = [];

    for (var i = 0; i < repeat; i++) {
        if (request.op === 'evalcb') {
            // The callback is the documented third parameter of `evaluate`.  What
            // is observed is how many times it was called and with what -- not the
            // error object it may receive, because on the failure path JSONata
            // rejects the promise and never calls it, and *that* is the case.
            var calls = [];
            var value = await expression.evaluate(input, bindings,
                function (err, resp) {
                    calls.push({ errNull: err === null, resp: resp });
                });
            results.push(value);
            callbacks.push(calls);
        } else {
            results.push(await expression.evaluate(input, bindings));
        }
    }

    var body = '{"results":[' + results.map(wire.encodeValue).join(',') + ']';
    if (request.op === 'evalcb') {
        body += ',"callbacks":[' + callbacks.map(function (calls) {
            return '[' + calls.map(function (call) {
                return '{"errNull":' + (call.errNull ? 'true' : 'false') +
                    ',"resp":' + wire.encodeValue(call.resp) + '}';
            }).join(',') + ']';
        }).join(',') + ']';
    }
    if (request.op === 'register') {
        body += ',"registered":[' + registered.map(wire.encodeString).join(',') + ']';
    }
    return body + '}';
}

// -- dispatch ---------------------------------------------------------------

/**
 * One line in, one response line out.  Never throws.
 *
 * The id is recovered as far as it can be and defaults to 0, so a request that is
 * not JSON at all still produces an addressable answer.  That is why the id is
 * read before the op is: a response with no id could not be matched to anything.
 */
async function handle(line) {
    var id = 0;
    var op = '';
    var request;
    try {
        request = JSON.parse(line);
    } catch (err) {
        return wire.encodeResponse(id, op, false,
            wire.encodeError(protocolError('P0001', String(err && err.message))));
    }
    if (request === null || typeof request !== 'object' || Array.isArray(request)) {
        return wire.encodeResponse(id, op, false,
            wire.encodeError(protocolError('P0002', '')));
    }
    if (!typeOk(request.id, 'integer')) {
        return wire.encodeResponse(id, op, false,
            wire.encodeError(protocolError('P0003', '')));
    }
    id = request.id;
    if (typeof request.op !== 'string') {
        return wire.encodeResponse(id, op, false,
            wire.encodeError(protocolError('P0004', '')));
    }
    op = request.op;
    if (!Object.prototype.hasOwnProperty.call(OP_FIELDS, op)) {
        return wire.encodeResponse(id, op, false,
            wire.encodeError(protocolError('P0005',
                '`' + op + '`; known: ' + Object.keys(OP_FIELDS).sort().join(', '))));
    }
    var bad = validate(request);
    if (bad) {
        return wire.encodeResponse(id, op, false, wire.encodeError(bad));
    }

    try {
        var body;
        if (op === 'hello') { body = opHello(); }
        else if (op === 'ast') { body = opAst(request); }
        else { body = await evaluateOp(request); }
        return wire.encodeResponse(id, op, true, body);
    } catch (err) {
        return wire.encodeResponse(id, op, false,
            wire.encodeError(classifyThrown(err)));
    }
}

// -- transport --------------------------------------------------------------

/**
 * Write every byte of `text` to a file descriptor, blocking until it is gone.
 *
 * `fs.writeSync` on a pipe can write fewer bytes than it was given, and it can
 * fail with EAGAIN when the reader is slow.  Both are normal and neither is an
 * error, so the loop retries rather than reporting a failure -- and because it
 * blocks, a response is in the pipe before the next request is read.  A probe that
 * buffered instead would lose every answer it had produced when a later request
 * killed it, and the whole batch would be attributed to the crash.
 */
function writeAll(fd, text) {
    var buffer = Buffer.from(text, 'utf8');
    var offset = 0;
    while (offset < buffer.length) {
        try {
            offset += fs.writeSync(fd, buffer, offset, buffer.length - offset);
        } catch (err) {
            if (err.code === 'EAGAIN') { continue; }
            if (err.code === 'EPIPE') { return; }
            throw err;
        }
    }
}

/** Read a whole file descriptor to a string.  Used for stdin and for --batch. */
function readAll(fd) {
    var chunks = [];
    var buffer = Buffer.alloc(1 << 16);
    while (true) {
        var read;
        try {
            read = fs.readSync(fd, buffer, 0, buffer.length, null);
        } catch (err) {
            if (err.code === 'EAGAIN') { continue; }
            if (err.code === 'EOF') { break; }
            throw err;
        }
        if (read <= 0) { break; }
        chunks.push(Buffer.from(buffer.slice(0, read)));
    }
    return Buffer.concat(chunks).toString('utf8');
}

/**
 * Split an NDJSON stream into lines.
 *
 * A trailing empty segment after the last newline is dropped; an *interior* blank
 * line is not, because a blank line is a request that is not JSON and the
 * protocol answers it with a P0001.  Dropping it would silently reduce the
 * response count and break the positional pairing the corpus relies on.
 *
 * A lone `\r` before a newline is left on the line rather than stripped: the
 * request is bytes, and a request whose framing carries a stray carriage return is
 * a request whose JSON parse fails.  Stripping it here would answer a question
 * nobody asked.
 */
function splitLines(text) {
    var lines = text.split('\n');
    if (lines.length && lines[lines.length - 1] === '') { lines.pop(); }
    return lines;
}

async function serve() {
    var lines = splitLines(readAll(0));
    for (var i = 0; i < lines.length; i++) {
        writeAll(1, (await handle(lines[i])) + '\n');
    }
    return 0;
}

async function batch(inPath, outPath) {
    var lines = splitLines(fs.readFileSync(inPath, 'utf8'));
    var fd = fs.openSync(outPath, 'w');
    try {
        for (var i = 0; i < lines.length; i++) {
            writeAll(fd, (await handle(lines[i])) + '\n');
        }
    } finally {
        fs.closeSync(fd);
    }
    return 0;
}

/**
 * Prove every advertised op dispatches and answers, then exit.
 *
 * Called by the verifier when it builds the reference, and available to anybody
 * porting this: a run that exits 0 has reached every op, both encoders and both
 * error paths.  It is not a test of correctness -- it asserts only that each op
 * produced a well-formed response with the right `ok` -- because correctness here
 * is defined by comparing two probes, and a probe that graded itself would be
 * asserting the answer it was written to produce.
 */
async function selfcheck() {
    var cases = [
        [{ id: 1, op: 'hello' }, true],
        [{ id: 2, op: 'ast', expr: 'a.b' }, true],
        [{ id: 3, op: 'ast', expr: 'a.', recover: true }, true],
        [{ id: 4, op: 'ast', expr: 'a.' }, false],
        [{ id: 5, op: 'eval', expr: '1+1' }, true],
        [{ id: 6, op: 'eval', expr: 'a.b', input: { a: [{ b: 1 }, { b: 2 }] } }, true],
        [{ id: 7, op: 'eval', expr: '$x', bindings: { x: 5 } }, true],
        [{ id: 8, op: 'eval', expr: '$notafunction()' }, false],
        [{ id: 9, op: 'eval', expr: '$now()' }, true],
        [{ id: 10, op: 'eval', expr: '$match("AB", /ab/)', options: { engine: 'caseless' } }, true],
        [{ id: 11, op: 'eval', expr: '$match("ab", /ab/)', options: { engine: 'broken' } }, false],
        [{ id: 12, op: 'evalcb', expr: '1+1' }, true],
        [{ id: 13, op: 'assign', expr: '$k', assigns: [{ name: 'k', value: 7 }] }, true],
        [{ id: 14, op: 'register', expr: '$d(4)', funcs: [{ name: 'd', impl: 'double' }] }, true],
        [{ id: 15, op: 'register', expr: '$t()', funcs: [{ name: 't', impl: 'throwing' }] }, false],
        [{ id: 16, op: 'eval', expr: '$millis()', repeat: 2 }, true],
        [{ id: 17, op: 'nope' }, false],
        [{ id: 18, op: 'eval', expr: '1', extra: 1 }, false],
        ['not json', false],
        [{ op: 'hello' }, false]
    ];
    var failures = [];
    for (var i = 0; i < cases.length; i++) {
        var request = cases[i][0];
        var line = typeof request === 'string' ? request : JSON.stringify(request);
        var answer = await handle(line);
        var parsed;
        try {
            parsed = JSON.parse(answer);
        } catch (err) {
            failures.push('case ' + i + ': response is not JSON: ' + answer.slice(0, 160));
            continue;
        }
        if (parsed.ok !== cases[i][1]) {
            failures.push('case ' + i + ': expected ok=' + cases[i][1] + ', got ' +
                JSON.stringify(parsed).slice(0, 200));
        }
        if (!('id' in parsed) || !('op' in parsed)) {
            failures.push('case ' + i + ': response lacks id or op');
        }
    }
    if (failures.length) {
        writeAll(2, 'probe selfcheck: ' + failures.length + ' failure(s)\n' +
            failures.join('\n') + '\n');
        return 1;
    }
    writeAll(1, 'probe selfcheck: ' + cases.length + ' op invocation(s) answered\n');
    return 0;
}

async function main(argv) {
    if (argv[0] === '--selfcheck') { return await selfcheck(); }
    if (argv[0] === '--batch') {
        if (argv.length < 3) {
            writeAll(2, 'usage: probe.js --batch <requests.ndjson> <responses.ndjson>\n');
            return 2;
        }
        return await batch(argv[1], argv[2]);
    }
    if (argv.length) {
        writeAll(2, 'usage: probe.js [--batch <in> <out>] [--selfcheck]\n');
        return 2;
    }
    return await serve();
}

if (require.main === module) {
    main(process.argv.slice(2)).then(function (code) {
        process.exitCode = code;
    }, function (err) {
        writeAll(2, 'probe: ' + (err && err.stack ? err.stack : String(err)) + '\n');
        process.exitCode = 70;
    });
}

module.exports = { handle: handle, main: main, PROTOCOL_VERSION: PROTOCOL_VERSION };
