'use strict';
/**
 * The named things a request may ask for.
 *
 * A request is data.  It never carries code -- no JavaScript source to be
 * `eval`ed, no function body to be constructed -- because a probe that executed
 * text from its input would be a remote code execution service rather than a
 * measurement instrument, and because a corpus of function bodies would grade
 * whichever language those bodies were written in.
 *
 * So everything a case might need a *function* for lives here under a name, and
 * the case names it.  `{"op":"register","funcs":[{"name":"dbl","impl":"double"}]}`
 * registers the `double` entry below as `$dbl`.  The set is closed: an unknown
 * name is a ProtocolError, not a lookup that returns undefined.
 *
 * Everything in this file is part of the contract.  A port reproduces these
 * behaviours -- including `throwing`, whose whole job is to raise a non-JSONata
 * error so the `Panic` path can be measured, and `mulberry32`, whose exact
 * integer arithmetic is what makes `$random()` an answer rather than a coin flip.
 */

// ---------------------------------------------------------------------------
// The clock
//
// JSONata's `$now()` and `$millis()` read the wall clock, and `$random()` reads
// `Math.random`.  Left alone, three of the language's built-ins would make every
// case that touches them unanswerable: the reference's frozen answer would be a
// timestamp from the moment the image was built, and no submission could ever
// match it.
//
// The fix is not to exclude them.  They are part of the language and a port that
// forgot `$now` should be caught.  Instead the probe *shadows* all three, through
// the same public `registerFunction` any consumer would use, before every
// evaluation.  The bound values below are fixed constants, so the answers are
// stable across runs, across machines and across the years between the freeze and
// a grading run -- and a case may opt out with `"clock":"live"`, in which case its
// result is not compared (see the `clock` field in the probe contract).
//
// FIXED_MILLIS is 2023-11-14T22:13:20.000Z, chosen because it is round in
// milliseconds and unremarkable in every other way.
var FIXED_MILLIS = 1700000000000;

// The seed for the pinned `$random()`.  0x9E3779B9 is the golden-ratio constant;
// it is a seed, not a magic number, and any port must use this one.
var RANDOM_SEED = 0x9E3779B9;

// ---------------------------------------------------------------------------
// Authored errors
//
// A `Panic` is whatever was thrown that JSONata did not throw itself, and its
// message comes from one of two places: this file, or the host runtime.  The two
// are not comparable.  Text written here is contract -- fixed, path-free, and
// reproducible by any port that ports this file.  Text the runtime wrote is not:
// `"Cannot create property 'n' on number '1'"` is V8's sentence about V8's
// failure, it names the value and the property it happened to be given, and
// grading it would be grading the engine underneath the port rather than the
// port.
//
// So the two are distinguished at the throw site rather than guessed at the wire.
// An error raised through this function carries `AUTHORED` and its message is
// published; anything else reaches the wire as its normalised `cause` alone.
// Testing for a `'probe fixture: '` prefix instead would work today and would be
// the wrong contract: it makes the marker a string in a message rather than a
// property of the error, and the first fixture whose text reads differently would
// silently lose its message.

/** The property that says "this file wrote this message". */
var AUTHORED = 'probeAuthored';

/**
 * An `Error` whose message is part of the protocol.
 *
 * `Error` and not a bare object: the `cause` token is derived from the thrown
 * value's class (see `panicCause`), so a fixture that threw a plain object would
 * report `thrown-object` and stop measuring the path it exists to measure.
 */
function authoredError(message) {
    var err = new Error(message);
    err[AUTHORED] = true;
    return err;
}

/**
 * mulberry32, the pinned `$random()`.
 *
 * Specified in full because "use a PRNG" is not a contract.  Every operation is
 * on unsigned 32-bit integers, `Math.imul` is a 32-bit multiply that wraps, and
 * the result is divided by 2^32 to land in [0, 1).  A port that reproduces these
 * five lines produces the same stream; one that reaches for its platform's
 * generator produces a different one, and the corpus says so.
 */
function mulberry32(seed) {
    var a = seed >>> 0;
    return function () {
        a = (a + 0x6D2B79F5) >>> 0;
        var t = a;
        t = Math.imul(t ^ (t >>> 15), t | 1) >>> 0;
        t = (t ^ (t + Math.imul(t ^ (t >>> 7), t | 61))) >>> 0;
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
}

// ---------------------------------------------------------------------------
// Named implementations, for `op: "register"`
//
// Each entry is `[implementation, signature]`.  A null signature means the
// function is registered without one, which is a different behaviour and not an
// omission: an unsignatured function accepts anything and fails inside itself,
// while a signatured one is rejected by the signature validator with a T0410
// before the body runs.  Both paths are in the corpus.
//
// `this` inside an implementation is JSONata's Focus: `this.input` is the
// document under evaluation and `this.environment.lookup` reads a binding.  Two
// entries exercise it, because a port that registers functions with the wrong
// receiver passes every case that does not look at `this`.
var IMPLS = {
    // The ordinary case.  Signatured, one number in, one number out.
    'double': [function (x) { return x * 2; }, '<n:n>'],

    // Two strings in, one out.  Present so a case can check argument order,
    // which a port that reverses its argument array gets wrong here and
    // nowhere else.
    'concat2': [function (a, b) { return a + b; }, '<ss:s>'],

    // No signature at all.  Accepts anything JSONata can pass, including
    // `undefined`, and reports what it got -- so a case can observe that an
    // unsignatured function is *reached* with an argument a signatured one
    // would have rejected.
    'describe': [function (v) {
        if (v === undefined) { return 'undefined'; }
        if (v === null) { return 'null'; }
        if (Array.isArray(v)) { return 'array:' + v.length; }
        return typeof v;
    }, null],

    // Raises a plain JavaScript error, which is the only way to reach the
    // `Panic` kind deterministically.  Raised through `authoredError` so the text
    // reaches the wire: a Panic message this file did not write is the host
    // runtime's own wording and is dropped.  See `classifyThrown` in probe.js.
    'throwing': [function () { throw authoredError('probe fixture: throwing() always raises'); }, '<:s>'],

    // Raises a *JSONata-shaped* error: an object with a `code`.  JSONata does not
    // distinguish this from one of its own, so it is reported as a JsonataError,
    // which is the behaviour and not a defect.  Present because a port that
    // wraps every thrown value into a Panic gets this case wrong.
    'throwingCode': [function () {
        throw { code: 'T2099', position: 0, token: 'fixture', message: 'probe fixture: coded failure' };
    }, '<:s>'],

    // Reads the document through the Focus receiver.
    'focusInput': [function () { return this.input; }, null],

    // Reads a binding through the Focus environment.  `$v` is bound by the
    // `assign` op and by request bindings, so a case can assign and then observe
    // the assignment from inside a registered function.
    'focusLookup': [function (name) { return this.environment.lookup(name); }, '<s:x>'],

    // Returns a promise.  JSONata awaits it, so the answer is the resolved value
    // -- a port that returns the promise itself encodes an `x` tag instead.
    'asyncDouble': [function (x) {
        return Promise.resolve(x * 2);
    }, '<n:n>'],

    // Returns a lambda.  The answer is therefore an `f` tag, and its `kind` says
    // whether the port kept the distinction between a native function and a
    // JSONata lambda.
    'makeAdder': [function (n) {
        return function (x) { return x + n; };
    }, '<n:f>'],

    // Mutable state across calls, within one registration.  A port that rebuilds
    // its environment per call returns 1 every time.
    'counter': [(function () {
        var n = 0;
        return function () { n += 1; return n; };
    })(), '<:n>'],

    // Always `undefined`, which in JSONata means "no match" and is not `null`.
    'nothing': [function () { return undefined; }, null],

    // A host object JSONata has no type for.  Nothing an expression can write
    // produces one -- every JSONata value is a primitive, a plain object, an array,
    // or a callable -- so without a fixture like this the wire's `x` tag would be
    // documented and unreachable, and a port could get it wrong for free.  The
    // library passes the value through untouched; what the wire reports is the
    // constructor's name.
    'hostDate': [function () { return new Date(0); }, null],

    // The same thing with a different constructor, so the case distinguishes
    // "reports `x`" from "reports `x` with the right name".
    'hostMap': [function () { return new Map(); }, null]
};

/**
 * Look up a named implementation.  Returns `[impl, signature]` or null.
 *
 * `counter` is rebuilt per lookup so that its state is per-registration rather
 * than per-process: two requests that each register it both start at 1, which is
 * what makes the case reproducible.  Every other entry is stateless and is
 * returned as it is.
 */
function implFor(name) {
    if (!Object.prototype.hasOwnProperty.call(IMPLS, name)) { return null; }
    if (name === 'counter') {
        var n = 0;
        return [function () { n += 1; return n; }, '<:n>'];
    }
    return IMPLS[name];
}

/** Every registerable name, sorted.  Reported by `hello`. */
function implNames() {
    return Object.keys(IMPLS).sort();
}

// ---------------------------------------------------------------------------
// Named RegExp engines, for `op: "eval"` with `"engine": <name>`
//
// `options.RegexEngine` replaces the constructor JSONata uses for every regex in
// an expression.  The contract it must satisfy is narrow and undocumented
// upstream: construct from `(source, flags)`, carry a mutable `lastIndex`, and
// expose an `exec(string)` that returns a match array with an `index` or null.
// A port that threads the option through untouched passes these; one that ignores
// the option and uses its platform's regex passes only `native`.
//
// One sharp edge, learned by running into it: what JSONata hands the constructor is
// the `RegExp` the *parser* built, not a source string, and that object already
// carries `g`.  Rebuilding it as `new RegExp(thatObject, 'i')` replaces the flags
// wholesale and silently drops `g`, after which `exec` stops advancing `lastIndex`
// and the `next()` chain in `evaluateRegex` walks the same match forever.  Any
// engine that rebuilds must therefore merge flags rather than set them -- hence
// `reflags` below, which every rebuilding engine goes through.
var ENGINES = {
    // The platform's own, passed explicitly.  Answers must match an expression
    // evaluated with no engine option at all -- that equality is the case.
    'native': function () { return RegExp; },

    // Forces the `i` flag on.  Chosen because the difference is visible in the
    // *result* of a match rather than in a count: `$match("AB", /ab/)` finds
    // nothing with the native engine and one match with this one.
    'caseless': function () {
        return function Caseless(source, flags) {
            return reflags(source, flags, 'i');
        };
    },

    // Never matches.  A port that discards the engine option returns real
    // matches here, which is the most legible possible failure.
    'nomatch': function () {
        return function NoMatch() {
            return { lastIndex: 0, exec: function () { return null; } };
        };
    },

    // Throws from its constructor, reaching the `Panic` path through a route that
    // has nothing to do with a registered function.
    'broken': function () {
        return function Broken() {
            throw authoredError('probe fixture: broken regex engine');
        };
    }
};

/**
 * Rebuild a pattern with `extra` flags added to the ones it already has.
 *
 * `source` is whatever JSONata passed the constructor: a `RegExp` from the parser
 * (the normal case, flags included) or a string.  `flags` is what the caller gave
 * separately, if anything.  The union is taken and `g` is always present, because
 * the closure in `evaluateRegex` drives iteration through `lastIndex` and a pattern
 * without `g` never advances it.
 */
function reflags(source, flags, extra) {
    var pattern = source instanceof RegExp ? source.source : String(source);
    var have = (source instanceof RegExp ? source.flags : '') + String(flags || '');
    var merged = '';
    var all = have + extra + 'g';
    for (var i = 0; i < all.length; i++) {
        if (merged.indexOf(all[i]) < 0) { merged += all[i]; }
    }
    return new RegExp(pattern, merged);
}

/** The constructor for a named engine, or null. */
function engineFor(name) {
    if (!Object.prototype.hasOwnProperty.call(ENGINES, name)) { return null; }
    return ENGINES[name]();
}

/** Every engine name, sorted.  Reported by `hello`. */
function engineNames() {
    return Object.keys(ENGINES).sort();
}

module.exports.AUTHORED = AUTHORED;
module.exports.authoredError = authoredError;
module.exports.FIXED_MILLIS = FIXED_MILLIS;
module.exports.RANDOM_SEED = RANDOM_SEED;
module.exports.mulberry32 = mulberry32;
module.exports.engineFor = engineFor;
module.exports.engineNames = engineNames;
module.exports.implFor = implFor;
module.exports.implNames = implNames;
