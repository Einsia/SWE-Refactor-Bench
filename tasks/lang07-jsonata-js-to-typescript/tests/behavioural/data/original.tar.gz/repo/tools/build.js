'use strict';
/**
 * The build, for the tree as it stands today.
 *
 * `dist/` is the delivered surface: `dist/jsonata.js` is the library, and
 * `dist/probe.js` is the differential probe that speaks the protocol in
 * `README.swerefactor.md`.  Everything that consumes this package -- including the
 * grader -- reads `dist/`, never `src/`.
 *
 * Today `src/` is JavaScript, so there is nothing to compile: this script loads
 * every module to prove it is syntactically valid and its `require` graph
 * resolves, copies the graph into `dist/`, writes the hand-maintained
 * `jsonata.d.ts` beside it, and runs the probe's own self-check.  That is a real
 * build in the sense that matters -- it fails when the tree is broken and its
 * output is what ships -- and a thin one, because a JavaScript project's build
 * step has little to do.
 *
 * It is deliberately dependency-free and offline.  Upstream's `package.json`
 * carried browserify, babel, uglify, mocha, nyc and eslint; none of them are here,
 * and `npm install` has nothing to fetch.
 *
 * A port of this repository is expected to replace this file.  A build that
 * compiles will have a compiler to invoke and will not need to hand-roll a
 * dependency walk -- what it does need to keep is the contract: after
 * `npm run build`, `node dist/probe.js` speaks the protocol, and `dist/` carries
 * the library and its type declarations under the names below.
 */

var fs = require('fs');
var path = require('path');

var ROOT = path.resolve(__dirname, '..');
var SRC = path.join(ROOT, 'src');
var DIST = path.join(ROOT, 'dist');

// The entry points.  `dist/jsonata.js` is what a consumer requires;
// `dist/probe.js` is what the grader runs.  Everything else in `dist/` is here
// because one of these two reaches it.
var ENTRIES = ['jsonata.js', 'probe.js'];

// The type declarations.  Hand-maintained today, upstream's own file, and the
// specification of the public API: a consumer written against this compiles
// against the built package.
var DECLARATION = 'jsonata.d.ts';

/** Every `require('./x')` in a source file, as a filename. */
function localRequires(text) {
    var out = [];
    var re = /require\(\s*'\.\/([A-Za-z0-9_-]+)'\s*\)/g;
    var m;
    while ((m = re.exec(text)) !== null) {
        out.push(m[1] + '.js');
    }
    return out;
}

/**
 * The transitive closure of `ENTRIES` over local requires, sorted.
 *
 * Sorted rather than in discovery order so that the file list this build reports
 * is a property of the tree and not of the order the walk happened to take.
 */
function moduleGraph() {
    var seen = Object.create(null);
    var queue = ENTRIES.slice();
    while (queue.length) {
        var name = queue.shift();
        if (seen[name]) { continue; }
        var file = path.join(SRC, name);
        if (!fs.existsSync(file)) {
            throw new Error('src/' + name + ' is required but missing');
        }
        seen[name] = fs.readFileSync(file, 'utf8');
        localRequires(seen[name]).forEach(function (dep) { queue.push(dep); });
    }
    return Object.keys(seen).sort().map(function (name) {
        return { name: name, text: seen[name] };
    });
}

function rmrf(target) {
    if (fs.existsSync(target)) {
        fs.rmSync(target, { recursive: true, force: true });
    }
}

function main() {
    var modules = moduleGraph();

    // Load the entry points before writing anything.  A tree that does not load
    // should fail the build rather than ship.
    ENTRIES.forEach(function (name) {
        require(path.join(SRC, name));
    });

    rmrf(DIST);
    fs.mkdirSync(DIST, { recursive: true });
    modules.forEach(function (mod) {
        fs.writeFileSync(path.join(DIST, mod.name), mod.text);
    });
    fs.copyFileSync(path.join(ROOT, DECLARATION), path.join(DIST, DECLARATION));

    // The probe's own self-check, run against the copy in `dist/` rather than the
    // one in `src/`, because `dist/` is what ships.
    var probe = require(path.join(DIST, 'probe.js'));
    return probe.main(['--selfcheck']).then(function (code) {
        if (code !== 0) {
            throw new Error('dist/probe.js --selfcheck exited ' + code);
        }
        process.stdout.write('build: ' + modules.length + ' module(s) + ' +
            DECLARATION + ' -> dist/\n');
    });
}

main().catch(function (err) {
    process.stderr.write('build failed: ' + (err && err.message ? err.message : err) + '\n');
    process.exitCode = 1;
});
